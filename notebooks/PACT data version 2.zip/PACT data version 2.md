

```python
### Import packages to pull json files from web
import requests
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import matplotlib.pyplot as plt
from urllib.request import urlretrieve
```


```python
### Assign URL to variable: url
url = 'https://raw.githubusercontent.com/BIOF309/group-project-rmndr/master/Family_PACT_Providers_File.csv'
```


```python
### Apply pandas package to read the .csv file: url
df = pd.read_csv(url)
```


```python
### Display the dataframe in Notebook
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Provider_Number</th>
      <th>NPI_Provider_Number</th>
      <th>Owner_Number</th>
      <th>Service_Location_Number</th>
      <th>Provider_Businness_Legal_Name</th>
      <th>Enrollment_Status_Effective_dat</th>
      <th>Provider_Type_Code</th>
      <th>Provider_Type_Code_Desc</th>
      <th>...</th>
      <th>Provider_Address_Line_1</th>
      <th>Provider_Address_Line_2</th>
      <th>Provider_Address_City</th>
      <th>Provider_Address_State</th>
      <th>Provider_Address_Zip</th>
      <th>Provider_Address_Latitude</th>
      <th>Provider_Address_Longitude</th>
      <th>MSSA_ID</th>
      <th>TRACT_ID</th>
      <th>FID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-118.160002</td>
      <td>33.889872</td>
      <td>1518996313</td>
      <td>1518996313</td>
      <td>1</td>
      <td>1</td>
      <td>BEHROOZ YAGOOBIAN, MD</td>
      <td>1995-08-14T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>15730 PARAMOUNT BLVD</td>
      <td>NaN</td>
      <td>PARAMOUNT</td>
      <td>CA</td>
      <td>90723</td>
      <td>33.889872</td>
      <td>-118.160002</td>
      <td>78.2m</td>
      <td>5539.01</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-118.239588</td>
      <td>34.137132</td>
      <td>1356362743</td>
      <td>1356362743</td>
      <td>1</td>
      <td>1</td>
      <td>COMPREHENSIVE COMM HLTH</td>
      <td>2006-12-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>801 S CHEVY CHASE DR</td>
      <td>STE 250</td>
      <td>GLENDALE</td>
      <td>CA</td>
      <td>91205</td>
      <td>34.137132</td>
      <td>-118.239588</td>
      <td>78.2ff</td>
      <td>3021.02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-118.147588</td>
      <td>33.972803</td>
      <td>1184833501</td>
      <td>1184833501</td>
      <td>1</td>
      <td>1</td>
      <td>BELL GARDEN FAMILY</td>
      <td>2003-08-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>6501 GARFIELD AVE</td>
      <td>NaN</td>
      <td>BELL GARDENS</td>
      <td>CA</td>
      <td>90201</td>
      <td>33.972803</td>
      <td>-118.147588</td>
      <td>78.2c</td>
      <td>5339.02</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>90201</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>90201</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-118.208139</td>
      <td>34.030985</td>
      <td>1710261284</td>
      <td>1710261284</td>
      <td>1</td>
      <td>1</td>
      <td>BELLA MEDICAL GROUP INC</td>
      <td>2012-03-26T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>2933 WHITTIER BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90023</td>
      <td>34.030985</td>
      <td>-118.208139</td>
      <td>78.2h</td>
      <td>2047.00</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-118.120765</td>
      <td>33.882105</td>
      <td>1932115375</td>
      <td>1932115375</td>
      <td>1</td>
      <td>1</td>
      <td>BELLFLOWER HEALTH CENTER</td>
      <td>1997-04-10T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>10005 E FLOWER AVE</td>
      <td>NaN</td>
      <td>BELLFLOWER</td>
      <td>CA</td>
      <td>90706</td>
      <td>33.882105</td>
      <td>-118.120765</td>
      <td>78.2m</td>
      <td>5542.03</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-117.435811</td>
      <td>34.103851</td>
      <td>1487742979</td>
      <td>1487742979</td>
      <td>1</td>
      <td>1</td>
      <td>BENNY J, GUZMAN, M.D., CORPO</td>
      <td>2003-09-04T07:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>8253 SIERRA AVE</td>
      <td>SUITE 200</td>
      <td>FONTANA</td>
      <td>CA</td>
      <td>92335</td>
      <td>34.103851</td>
      <td>-117.435811</td>
      <td>151h</td>
      <td>30.00</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-122.269858</td>
      <td>37.863641</td>
      <td>1518963693</td>
      <td>1518963693</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PRIMARY CARE</td>
      <td>1996-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>2001 DWIGHT WAY</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>94704</td>
      <td>37.863641</td>
      <td>-122.269858</td>
      <td>2a</td>
      <td>4235.00</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-122.297686</td>
      <td>37.867938</td>
      <td>1902944796</td>
      <td>1902944796</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PUBLIC HLTH CLINIC</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>41</td>
      <td>COMMUNITY CLINIC</td>
      <td>...</td>
      <td>830 UNIVERSITY AVE</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>94710</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>-122.297686</td>
      <td>37.867938</td>
      <td>1902944796</td>
      <td>1902944796</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PUBLIC HLTH CLINIC</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>830 UNIVERSITY AVE</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>94710</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>-117.140230</td>
      <td>32.708729</td>
      <td>1861603151</td>
      <td>1861603151</td>
      <td>1</td>
      <td>1</td>
      <td>25TH ST FAMILY MEDICINE</td>
      <td>2007-07-23T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>316 25TH ST</td>
      <td>NaN</td>
      <td>SAN DIEGO</td>
      <td>CA</td>
      <td>92102</td>
      <td>32.708729</td>
      <td>-117.140230</td>
      <td>161c</td>
      <td>48.00</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>-118.220823</td>
      <td>33.973776</td>
      <td>1912928540</td>
      <td>1912928540</td>
      <td>1</td>
      <td>1</td>
      <td>BERNARDITA DE LOS REYES</td>
      <td>2000-04-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>2760 E FLORENCE AVE</td>
      <td>NaN</td>
      <td>HUNTINGTON PARK</td>
      <td>CA</td>
      <td>90255</td>
      <td>33.973776</td>
      <td>-118.220823</td>
      <td>78.2ccc</td>
      <td>5331.07</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>-119.009485</td>
      <td>35.396189</td>
      <td>1588798870</td>
      <td>1588798870</td>
      <td>1</td>
      <td>1</td>
      <td>34TH STREET COMMUNITY HEALTH</td>
      <td>1997-02-05T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>2000 PHYSICIANS BLVD</td>
      <td>NaN</td>
      <td>BAKERSFIELD</td>
      <td>CA</td>
      <td>93301</td>
      <td>35.396189</td>
      <td>-119.009485</td>
      <td>66a</td>
      <td>6.00</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>-118.275105</td>
      <td>34.055679</td>
      <td>1689978850</td>
      <td>1689978850</td>
      <td>1</td>
      <td>1</td>
      <td>7TH ST MEDICAL GROUP</td>
      <td>2011-03-22T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>1919 W 7TH ST</td>
      <td>STE 2A</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90057</td>
      <td>34.055679</td>
      <td>-118.275105</td>
      <td>78.2b</td>
      <td>2094.02</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>-117.161281</td>
      <td>32.740195</td>
      <td>1568800100</td>
      <td>1568800100</td>
      <td>1</td>
      <td>1</td>
      <td>BEST START MIDWIFE SERVICES</td>
      <td>2015-02-02T08:00:00.000Z</td>
      <td>5</td>
      <td>CERTIFIED NURSE MIDWIFE</td>
      <td>...</td>
      <td>3343 4TH AVE</td>
      <td>NaN</td>
      <td>SAN DIEGO</td>
      <td>CA</td>
      <td>92103</td>
      <td>32.740195</td>
      <td>-117.161281</td>
      <td>161e</td>
      <td>60.00</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>-118.100423</td>
      <td>34.016047</td>
      <td>1184628919</td>
      <td>1184628919</td>
      <td>1</td>
      <td>1</td>
      <td>BEVERLY HOSPITAL</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>15</td>
      <td>COMMUNITY OUTPATIENT HOSPITAL</td>
      <td>...</td>
      <td>309 W BEVERLY BLVD</td>
      <td>NaN</td>
      <td>MONTEBELLO</td>
      <td>CA</td>
      <td>90640</td>
      <td>34.016047</td>
      <td>-118.100423</td>
      <td>78.2nn</td>
      <td>5300.04</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>-118.387784</td>
      <td>34.205963</td>
      <td>1396067500</td>
      <td>1396067500</td>
      <td>1</td>
      <td>1</td>
      <td>AAA COMPREHENSIVE HEALTHCARE</td>
      <td>2010-04-30T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>7451 N LANKERSHIM BLVD</td>
      <td>NaN</td>
      <td>NORTH HOLLYWOOD</td>
      <td>CA</td>
      <td>91605</td>
      <td>34.205963</td>
      <td>-118.387784</td>
      <td>78.2bb</td>
      <td>1224.10</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>-118.352348</td>
      <td>33.878380</td>
      <td>1629192133</td>
      <td>1629192133</td>
      <td>1</td>
      <td>1</td>
      <td>BEVERLY, SHEREEN L MD</td>
      <td>1990-02-28T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>16812 HAWTHORNE BLVD</td>
      <td>NaN</td>
      <td>LAWNDALE</td>
      <td>CA</td>
      <td>90260</td>
      <td>33.878380</td>
      <td>-118.352348</td>
      <td>78.2iiii</td>
      <td>6041.00</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>-118.256403</td>
      <td>33.961796</td>
      <td>1316061674</td>
      <td>1316061674</td>
      <td>1</td>
      <td>1</td>
      <td>ABAIAN, ALI MD</td>
      <td>2001-04-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>8460 S CENTRAL AVENUE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90001</td>
      <td>33.961796</td>
      <td>-118.256403</td>
      <td>78.2fff</td>
      <td>2398.02</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>-117.854493</td>
      <td>33.759883</td>
      <td>1861680712</td>
      <td>1861680712</td>
      <td>1</td>
      <td>1</td>
      <td>BIENESTAR MEDICAL CENTER</td>
      <td>2006-11-02T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>1125 E 17TH STREET</td>
      <td>SUITE N 152</td>
      <td>SANTA ANA</td>
      <td>CA</td>
      <td>92701</td>
      <td>33.759883</td>
      <td>-117.854493</td>
      <td>116h</td>
      <td>754.03</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>-116.239207</td>
      <td>33.707410</td>
      <td>1043281108</td>
      <td>1043281108</td>
      <td>1</td>
      <td>1</td>
      <td>ABHYANKAR, S.R. MD PC</td>
      <td>2006-04-11T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>81-709 DR CARREON BLVD</td>
      <td>STE C1</td>
      <td>INDIO</td>
      <td>CA</td>
      <td>92201</td>
      <td>33.707410</td>
      <td>-116.239207</td>
      <td>128</td>
      <td>452.07</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>-118.155282</td>
      <td>34.026948</td>
      <td>1497001226</td>
      <td>1497001226</td>
      <td>1</td>
      <td>1</td>
      <td>BIENVENIDOS COMMUNITY HEALTH</td>
      <td>2013-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>507 S. ATLANTIC BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90022</td>
      <td>34.026948</td>
      <td>-118.155282</td>
      <td>78.2d</td>
      <td>5303.01</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>-116.888382</td>
      <td>34.244060</td>
      <td>1578535845</td>
      <td>1578535845</td>
      <td>1</td>
      <td>5</td>
      <td>BIG BEAR PUBLIC HEALTH CLINI</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>477 SUMMIT BLVD</td>
      <td>NaN</td>
      <td>BIG BEAR LAKE</td>
      <td>CA</td>
      <td>92315</td>
      <td>34.244060</td>
      <td>-116.888382</td>
      <td>146</td>
      <td>112.03</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>-121.299230</td>
      <td>37.961437</td>
      <td>1073619060</td>
      <td>1073619060</td>
      <td>1</td>
      <td>1</td>
      <td>BIG VALLEY OB-GYN MEDICAL</td>
      <td>1988-01-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>420 W ACACIA ST</td>
      <td>STE 11</td>
      <td>STOCKTON</td>
      <td>CA</td>
      <td>95203</td>
      <td>37.961437</td>
      <td>-121.299230</td>
      <td>169b</td>
      <td>4.01</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>-121.690577</td>
      <td>39.366966</td>
      <td>1578708285</td>
      <td>1578708285</td>
      <td>1</td>
      <td>1</td>
      <td>BIGGS GRIDLEY HOSP</td>
      <td>1998-10-13T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>240 SPRUCE ST</td>
      <td>NaN</td>
      <td>GRIDLEY</td>
      <td>CA</td>
      <td>95948</td>
      <td>39.366966</td>
      <td>-121.690577</td>
      <td>9</td>
      <td>35.02</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>-117.370486</td>
      <td>34.103910</td>
      <td>1275656761</td>
      <td>1275656761</td>
      <td>1</td>
      <td>1</td>
      <td>BIR, RAGHBIR S MD</td>
      <td>1998-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>280 N RIVERSIDE AVE</td>
      <td>NaN</td>
      <td>RIALTO</td>
      <td>CA</td>
      <td>92376</td>
      <td>34.103910</td>
      <td>-117.370486</td>
      <td>151h</td>
      <td>37.00</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>-117.435763</td>
      <td>34.075913</td>
      <td>1568585024</td>
      <td>1568585024</td>
      <td>1</td>
      <td>1</td>
      <td>BIR, RAGHBIR S MD</td>
      <td>2001-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>9792 SIERRA AVE</td>
      <td>NaN</td>
      <td>FONTANA</td>
      <td>CA</td>
      <td>92335</td>
      <td>34.075913</td>
      <td>-117.435763</td>
      <td>151f</td>
      <td>33.01</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>-118.418372</td>
      <td>37.362022</td>
      <td>1659433191</td>
      <td>1659433191</td>
      <td>1</td>
      <td>3</td>
      <td>BISHOP CLINIC</td>
      <td>1991-11-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>52 TU SU LANE</td>
      <td>NaN</td>
      <td>BISHOP</td>
      <td>CA</td>
      <td>93514</td>
      <td>37.362022</td>
      <td>-118.418372</td>
      <td>53</td>
      <td>4.00</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>-117.919049</td>
      <td>33.649959</td>
      <td>1841419793</td>
      <td>1841419793</td>
      <td>1</td>
      <td>1</td>
      <td>BLACK, ROBIN</td>
      <td>2007-02-07T08:00:00.000Z</td>
      <td>7</td>
      <td>CERTIFIED NURSE PRACTIONER</td>
      <td>...</td>
      <td>2077 HARBOR BLVD</td>
      <td>STE C</td>
      <td>COSTA MESA</td>
      <td>CA</td>
      <td>92627</td>
      <td>33.649959</td>
      <td>-117.919049</td>
      <td>116p</td>
      <td>637.02</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1800</th>
      <td>-122.271239</td>
      <td>37.799511</td>
      <td>1225179641</td>
      <td>1225179641</td>
      <td>1</td>
      <td>1</td>
      <td>ROLLAND AND KATHRYN LOWE MED</td>
      <td>1996-10-23T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>835 WEBSTER ST</td>
      <td>NaN</td>
      <td>OAKLAND</td>
      <td>CA</td>
      <td>94607</td>
      <td>37.799511</td>
      <td>-122.271239</td>
      <td>2c</td>
      <td>4030.00</td>
      <td>1801</td>
    </tr>
    <tr>
      <th>1801</th>
      <td>-118.212379</td>
      <td>33.972891</td>
      <td>1114032208</td>
      <td>1114032208</td>
      <td>1</td>
      <td>1</td>
      <td>ROMERO, JESUSA N MD APC</td>
      <td>1988-12-31T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>3100 E FLORENCE AVE</td>
      <td>STE 5</td>
      <td>HUNTINGTON PARK</td>
      <td>CA</td>
      <td>90255</td>
      <td>33.972891</td>
      <td>-118.212379</td>
      <td>78.2ccc</td>
      <td>5332.03</td>
      <td>1802</td>
    </tr>
    <tr>
      <th>1802</th>
      <td>-118.176068</td>
      <td>33.969061</td>
      <td>1861576480</td>
      <td>1861576480</td>
      <td>1</td>
      <td>1</td>
      <td>ROMO, MARY S MD INC</td>
      <td>1991-12-31T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>5101 FLORENCE AVE</td>
      <td>STE 5</td>
      <td>BELL</td>
      <td>CA</td>
      <td>90201</td>
      <td>33.969061</td>
      <td>-118.176068</td>
      <td>78.2ddd</td>
      <td>5338.05</td>
      <td>1803</td>
    </tr>
    <tr>
      <th>1803</th>
      <td>-118.445025</td>
      <td>34.068908</td>
      <td>1902803315</td>
      <td>1902803315</td>
      <td>1</td>
      <td>1</td>
      <td>RONALD REAGAN UCLA MED</td>
      <td>2005-07-01T07:00:00.000Z</td>
      <td>15</td>
      <td>COMMUNITY OUTPATIENT HOSPITAL</td>
      <td>...</td>
      <td>757 WESTWOOD PLAZA</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90095</td>
      <td>34.068908</td>
      <td>-118.445025</td>
      <td>78.2w</td>
      <td>2653.01</td>
      <td>1804</td>
    </tr>
    <tr>
      <th>1804</th>
      <td>-122.237990</td>
      <td>37.789727</td>
      <td>1851522015</td>
      <td>1851522015</td>
      <td>1</td>
      <td>1</td>
      <td>ROOSEVELT HEALTH CENTER</td>
      <td>2009-11-12T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>1926 19TH AVE</td>
      <td>NaN</td>
      <td>OAKLAND</td>
      <td>CA</td>
      <td>94606</td>
      <td>37.789727</td>
      <td>-122.237990</td>
      <td>2c</td>
      <td>4059.02</td>
      <td>1805</td>
    </tr>
    <tr>
      <th>1805</th>
      <td>-122.741560</td>
      <td>38.429307</td>
      <td>1558512624</td>
      <td>1558512624</td>
      <td>1</td>
      <td>1</td>
      <td>ROSELAND PEDIATRICS</td>
      <td>2008-09-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>711 STONY POINT ROAD</td>
      <td>SUITE 17</td>
      <td>SANTA ROSA</td>
      <td>CA</td>
      <td>95407</td>
      <td>38.429307</td>
      <td>-122.741560</td>
      <td>210.1</td>
      <td>1531.04</td>
      <td>1806</td>
    </tr>
    <tr>
      <th>1806</th>
      <td>-118.396526</td>
      <td>34.215715</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>5</td>
      <td>ROY MEDICAL GROUP INC</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>8001 LAUREL CANYON BLVD</td>
      <td>STE 109</td>
      <td>NORTH HOLLYWOOD</td>
      <td>CA</td>
      <td>91605</td>
      <td>34.215715</td>
      <td>-118.396526</td>
      <td>78.2ppp</td>
      <td>1210.20</td>
      <td>1807</td>
    </tr>
    <tr>
      <th>1807</th>
      <td>-118.590600</td>
      <td>34.201103</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>1</td>
      <td>ROY, ROSALINDA A MD</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>21001 SHERMAN WAY</td>
      <td>STE 15</td>
      <td>CANOGA PARK</td>
      <td>CA</td>
      <td>91303</td>
      <td>34.201103</td>
      <td>-118.590600</td>
      <td>78.2hhhh</td>
      <td>1340.01</td>
      <td>1808</td>
    </tr>
    <tr>
      <th>1808</th>
      <td>-118.482831</td>
      <td>34.193904</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>2</td>
      <td>ROY, ROSALINDA A MD</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>16063 VANOWEN ST</td>
      <td>NaN</td>
      <td>VAN NUYS</td>
      <td>CA</td>
      <td>91406</td>
      <td>34.193904</td>
      <td>-118.482831</td>
      <td>78.2cc</td>
      <td>1276.05</td>
      <td>1809</td>
    </tr>
    <tr>
      <th>1809</th>
      <td>-117.642495</td>
      <td>34.068248</td>
      <td>1619144227</td>
      <td>1619144227</td>
      <td>1</td>
      <td>1</td>
      <td>ROYAL CARE MEDICAL CENTER</td>
      <td>2011-01-11T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>653 E E ST</td>
      <td>STE 109</td>
      <td>ONTARIO</td>
      <td>CA</td>
      <td>91764</td>
      <td>34.068248</td>
      <td>-117.642495</td>
      <td>151c</td>
      <td>15.01</td>
      <td>1810</td>
    </tr>
    <tr>
      <th>1810</th>
      <td>-118.160915</td>
      <td>34.034141</td>
      <td>1083627749</td>
      <td>1083627749</td>
      <td>1</td>
      <td>1</td>
      <td>ROYBAL COMPREHENSIVE HLT</td>
      <td>1997-04-10T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>245 S FETTERLY AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90022</td>
      <td>34.034141</td>
      <td>-118.160915</td>
      <td>78.2d</td>
      <td>5304.00</td>
      <td>1811</td>
    </tr>
    <tr>
      <th>1811</th>
      <td>-117.689596</td>
      <td>34.040964</td>
      <td>1740303247</td>
      <td>1740303247</td>
      <td>1</td>
      <td>1</td>
      <td>RS BIR MD INC CLINICA MEDIC</td>
      <td>1998-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>11692 CENTRAL AVE</td>
      <td>NaN</td>
      <td>CHINO</td>
      <td>CA</td>
      <td>91710</td>
      <td>34.040964</td>
      <td>-117.689596</td>
      <td>151l</td>
      <td>4.04</td>
      <td>1812</td>
    </tr>
    <tr>
      <th>1812</th>
      <td>-117.152437</td>
      <td>34.206947</td>
      <td>1881703957</td>
      <td>1881703957</td>
      <td>1</td>
      <td>1</td>
      <td>RURAL HEALTH CLINIC</td>
      <td>2008-01-09T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>31900 HILLTOP BLVD</td>
      <td>NaN</td>
      <td>RUNNING SPRINGS</td>
      <td>CA</td>
      <td>92382</td>
      <td>34.206947</td>
      <td>-117.152437</td>
      <td>146</td>
      <td>111.01</td>
      <td>1813</td>
    </tr>
    <tr>
      <th>1813</th>
      <td>-118.256479</td>
      <td>34.003304</td>
      <td>1396891909</td>
      <td>1396891909</td>
      <td>1</td>
      <td>1</td>
      <td>S CENTRAL FAMILY HLTH CT</td>
      <td>1994-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>4425 S CENTRAL AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90011</td>
      <td>34.003304</td>
      <td>-118.256479</td>
      <td>78.2ggg</td>
      <td>2286.00</td>
      <td>1814</td>
    </tr>
    <tr>
      <th>1814</th>
      <td>-118.274009</td>
      <td>34.010416</td>
      <td>1487923306</td>
      <td>1487923306</td>
      <td>1</td>
      <td>1</td>
      <td>S MARK TAPER FNDN HEALTH</td>
      <td>2012-03-09T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>4000 S MAIN STREET</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90037</td>
      <td>34.010416</td>
      <td>-118.274009</td>
      <td>78.2l</td>
      <td>2318.00</td>
      <td>1815</td>
    </tr>
    <tr>
      <th>1815</th>
      <td>-120.093733</td>
      <td>34.606060</td>
      <td>1992779417</td>
      <td>1992779417</td>
      <td>1</td>
      <td>1</td>
      <td>S Y BAND OF MISSION IND</td>
      <td>1991-09-27T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>90 VIA JUANA RD</td>
      <td>NaN</td>
      <td>SANTA YNEZ</td>
      <td>CA</td>
      <td>93460</td>
      <td>34.606060</td>
      <td>-120.093733</td>
      <td>178.1</td>
      <td>19.06</td>
      <td>1816</td>
    </tr>
    <tr>
      <th>1816</th>
      <td>-118.291710</td>
      <td>34.087012</td>
      <td>1891806329</td>
      <td>1891806329</td>
      <td>1</td>
      <td>2</td>
      <td>SABABA, LILIAN E MD</td>
      <td>1991-02-28T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>866 N VERMONT AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90029</td>
      <td>34.087012</td>
      <td>-118.291710</td>
      <td>78.2g</td>
      <td>1914.10</td>
      <td>1817</td>
    </tr>
    <tr>
      <th>1817</th>
      <td>-118.321100</td>
      <td>34.101663</td>
      <td>1235271065</td>
      <td>1235271065</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN COMMUNITY CLINIC</td>
      <td>1997-06-24T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>6043 HOLLYWOOD BLVD</td>
      <td>NaN</td>
      <td>HOLLYWOOD</td>
      <td>CA</td>
      <td>90028</td>
      <td>34.101663</td>
      <td>-118.321100</td>
      <td>78.2a</td>
      <td>1910.00</td>
      <td>1818</td>
    </tr>
    <tr>
      <th>1818</th>
      <td>-118.313671</td>
      <td>34.083520</td>
      <td>1336281179</td>
      <td>1336281179</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN COMMUNITY CLINIC</td>
      <td>2002-04-17T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>5205 MELROSE AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90038</td>
      <td>34.083520</td>
      <td>-118.313671</td>
      <td>78.2g</td>
      <td>1917.10</td>
      <td>1819</td>
    </tr>
    <tr>
      <th>1819</th>
      <td>-118.373295</td>
      <td>34.076063</td>
      <td>1194893248</td>
      <td>1194893248</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN FREE CLINIC BEVERLY</td>
      <td>1994-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>8405 BEVERLY BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>90048</td>
      <td>34.076063</td>
      <td>-118.373295</td>
      <td>78.2f</td>
      <td>1945.00</td>
      <td>1820</td>
    </tr>
    <tr>
      <th>1820</th>
      <td>-120.458268</td>
      <td>36.860624</td>
      <td>1558638601</td>
      <td>1558638601</td>
      <td>1</td>
      <td>1</td>
      <td>SABLAN HEALTH CENTER</td>
      <td>2012-03-12T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>927 O STREET</td>
      <td>NaN</td>
      <td>FIREBAUGH</td>
      <td>CA</td>
      <td>93622</td>
      <td>36.860624</td>
      <td>-120.458268</td>
      <td>25</td>
      <td>84.01</td>
      <td>1821</td>
    </tr>
    <tr>
      <th>1821</th>
      <td>-117.298641</td>
      <td>34.097379</td>
      <td>1801270137</td>
      <td>1801270137</td>
      <td>1</td>
      <td>1</td>
      <td>SAC SAN BERNARDINO CAMPUS</td>
      <td>2016-07-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>250 SOUTH G STREET</td>
      <td>NaN</td>
      <td>SAN BERNARDINO</td>
      <td>CA</td>
      <td>92410</td>
      <td>34.097379</td>
      <td>-117.298641</td>
      <td>151g</td>
      <td>57.01</td>
      <td>1822</td>
    </tr>
    <tr>
      <th>1822</th>
      <td>-121.450815</td>
      <td>38.610077</td>
      <td>1538180245</td>
      <td>1538180245</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMM CLINIC</td>
      <td>2006-11-22T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>2200 DEL PASO BLVD</td>
      <td>NaN</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>95815</td>
      <td>38.610077</td>
      <td>-121.450815</td>
      <td>139j</td>
      <td>69.00</td>
      <td>1823</td>
    </tr>
    <tr>
      <th>1823</th>
      <td>-121.437707</td>
      <td>38.493421</td>
      <td>1740336734</td>
      <td>1740336734</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMM CLINIC</td>
      <td>2006-11-21T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>7275 E SOUTHGATE DR</td>
      <td>STE 204-206</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>95823</td>
      <td>38.493421</td>
      <td>-121.437707</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1824</td>
    </tr>
    <tr>
      <th>1824</th>
      <td>-121.440792</td>
      <td>38.493662</td>
      <td>1295044832</td>
      <td>1295044832</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMMUNITY CLINIC</td>
      <td>2012-02-22T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>5524 ASSEMBLY COURT</td>
      <td>SUITE 200</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>95823</td>
      <td>38.493662</td>
      <td>-121.440792</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1825</td>
    </tr>
    <tr>
      <th>1825</th>
      <td>-121.479589</td>
      <td>38.576631</td>
      <td>1588756530</td>
      <td>1588756530</td>
      <td>1</td>
      <td>3</td>
      <td>SACRAMENTO NATIVE AMER</td>
      <td>2006-12-20T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>2020 J ST</td>
      <td>NaN</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>95811</td>
      <td>38.576631</td>
      <td>-121.479589</td>
      <td>139j</td>
      <td>11.01</td>
      <td>1826</td>
    </tr>
    <tr>
      <th>1826</th>
      <td>-117.667255</td>
      <td>33.557040</td>
      <td>1376905026</td>
      <td>1376905026</td>
      <td>1</td>
      <td>1</td>
      <td>SADDLEBACK COLLEGE</td>
      <td>2016-05-18T07:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>28000 MARGUERITE PARKWAY</td>
      <td>NaN</td>
      <td>MISSION VIEJO</td>
      <td>CA</td>
      <td>92692</td>
      <td>33.557040</td>
      <td>-117.667255</td>
      <td>115.2a</td>
      <td>320.22</td>
      <td>1827</td>
    </tr>
    <tr>
      <th>1827</th>
      <td>-117.941811</td>
      <td>33.850820</td>
      <td>1124296496</td>
      <td>1124296496</td>
      <td>1</td>
      <td>1</td>
      <td>SAENZ, LUCY M MD</td>
      <td>2002-12-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>1203 N EUCLID ST</td>
      <td>NaN</td>
      <td>ANAHEIM</td>
      <td>CA</td>
      <td>92801</td>
      <td>33.850820</td>
      <td>-117.941811</td>
      <td>116l</td>
      <td>867.01</td>
      <td>1828</td>
    </tr>
    <tr>
      <th>1828</th>
      <td>-117.853557</td>
      <td>33.759898</td>
      <td>1548367436</td>
      <td>1548367436</td>
      <td>1</td>
      <td>1</td>
      <td>SAENZ, LUCY M MD INC</td>
      <td>1998-05-01T07:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>1215 E 17TH ST</td>
      <td>NaN</td>
      <td>SANTA ANA</td>
      <td>CA</td>
      <td>92701</td>
      <td>33.759898</td>
      <td>-117.853557</td>
      <td>116h</td>
      <td>754.03</td>
      <td>1829</td>
    </tr>
    <tr>
      <th>1829</th>
      <td>-118.400917</td>
      <td>34.020459</td>
      <td>1306945241</td>
      <td>1306945241</td>
      <td>1</td>
      <td>1</td>
      <td>SAINT ANA WOMEN MED CLNC</td>
      <td>1999-02-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>3865 JASMINE AVE</td>
      <td>NaN</td>
      <td>CULVER CITY</td>
      <td>CA</td>
      <td>90232</td>
      <td>34.020459</td>
      <td>-118.400917</td>
      <td>78.2y</td>
      <td>2699.05</td>
      <td>1830</td>
    </tr>
  </tbody>
</table>
<p>1830 rows × 28 columns</p>
</div>




```python
print(np.shape(df))
```

    (1830, 28)
    


```python
type(df)
```




    pandas.core.frame.DataFrame




```python
### Get information on DataFrame
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1830 entries, 0 to 1829
    Data columns (total 28 columns):
    X                                  1830 non-null float64
    Y                                  1830 non-null float64
    Provider_Number                    1830 non-null int64
    NPI_Provider_Number                1830 non-null int64
    Owner_Number                       1830 non-null int64
    Service_Location_Number            1830 non-null int64
    Provider_Businness_Legal_Name      1830 non-null object
    Enrollment_Status_Effective_dat    1830 non-null object
    Provider_Type_Code                 1830 non-null int64
    Provider_Type_Code_Desc            1636 non-null object
    Provider_License_Number            685 non-null object
    Provider_Specialty_Code            633 non-null float64
    Provider_Specialty_Code_Desc       502 non-null object
    Out_of_State_Ind                   1830 non-null int64
    Out_of_State_Desc                  1830 non-null object
    Provider_Address_County_Code       1829 non-null float64
    Provider_Address_County_Code_De    1829 non-null object
    Provider_Address_Attention_Line    1017 non-null object
    Provider_Address_Line_1            1830 non-null object
    Provider_Address_Line_2            632 non-null object
    Provider_Address_City              1830 non-null object
    Provider_Address_State             1830 non-null object
    Provider_Address_Zip               1830 non-null int64
    Provider_Address_Latitude          1830 non-null float64
    Provider_Address_Longitude         1830 non-null float64
    MSSA_ID                            1830 non-null object
    TRACT_ID                           1830 non-null float64
    FID                                1830 non-null int64
    dtypes: float64(7), int64(8), object(13)
    memory usage: 400.4+ KB
    


```python
### Display the last 6 columns of the DataFrame
df.iloc[:,-6:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Provider_Address_Zip</th>
      <th>Provider_Address_Latitude</th>
      <th>Provider_Address_Longitude</th>
      <th>MSSA_ID</th>
      <th>TRACT_ID</th>
      <th>FID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>90723</td>
      <td>33.889872</td>
      <td>-118.160002</td>
      <td>78.2m</td>
      <td>5539.01</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>91205</td>
      <td>34.137132</td>
      <td>-118.239588</td>
      <td>78.2ff</td>
      <td>3021.02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>90201</td>
      <td>33.972803</td>
      <td>-118.147588</td>
      <td>78.2c</td>
      <td>5339.02</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>90201</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>90201</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>90023</td>
      <td>34.030985</td>
      <td>-118.208139</td>
      <td>78.2h</td>
      <td>2047.00</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>90706</td>
      <td>33.882105</td>
      <td>-118.120765</td>
      <td>78.2m</td>
      <td>5542.03</td>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>92335</td>
      <td>34.103851</td>
      <td>-117.435811</td>
      <td>151h</td>
      <td>30.00</td>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>94704</td>
      <td>37.863641</td>
      <td>-122.269858</td>
      <td>2a</td>
      <td>4235.00</td>
      <td>9</td>
    </tr>
    <tr>
      <th>9</th>
      <td>94710</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>94710</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>92102</td>
      <td>32.708729</td>
      <td>-117.140230</td>
      <td>161c</td>
      <td>48.00</td>
      <td>12</td>
    </tr>
    <tr>
      <th>12</th>
      <td>90255</td>
      <td>33.973776</td>
      <td>-118.220823</td>
      <td>78.2ccc</td>
      <td>5331.07</td>
      <td>13</td>
    </tr>
    <tr>
      <th>13</th>
      <td>93301</td>
      <td>35.396189</td>
      <td>-119.009485</td>
      <td>66a</td>
      <td>6.00</td>
      <td>14</td>
    </tr>
    <tr>
      <th>14</th>
      <td>90057</td>
      <td>34.055679</td>
      <td>-118.275105</td>
      <td>78.2b</td>
      <td>2094.02</td>
      <td>15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>92103</td>
      <td>32.740195</td>
      <td>-117.161281</td>
      <td>161e</td>
      <td>60.00</td>
      <td>16</td>
    </tr>
    <tr>
      <th>16</th>
      <td>90640</td>
      <td>34.016047</td>
      <td>-118.100423</td>
      <td>78.2nn</td>
      <td>5300.04</td>
      <td>17</td>
    </tr>
    <tr>
      <th>17</th>
      <td>91605</td>
      <td>34.205963</td>
      <td>-118.387784</td>
      <td>78.2bb</td>
      <td>1224.10</td>
      <td>18</td>
    </tr>
    <tr>
      <th>18</th>
      <td>90260</td>
      <td>33.878380</td>
      <td>-118.352348</td>
      <td>78.2iiii</td>
      <td>6041.00</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>90001</td>
      <td>33.961796</td>
      <td>-118.256403</td>
      <td>78.2fff</td>
      <td>2398.02</td>
      <td>20</td>
    </tr>
    <tr>
      <th>20</th>
      <td>92701</td>
      <td>33.759883</td>
      <td>-117.854493</td>
      <td>116h</td>
      <td>754.03</td>
      <td>21</td>
    </tr>
    <tr>
      <th>21</th>
      <td>92201</td>
      <td>33.707410</td>
      <td>-116.239207</td>
      <td>128</td>
      <td>452.07</td>
      <td>22</td>
    </tr>
    <tr>
      <th>22</th>
      <td>90022</td>
      <td>34.026948</td>
      <td>-118.155282</td>
      <td>78.2d</td>
      <td>5303.01</td>
      <td>23</td>
    </tr>
    <tr>
      <th>23</th>
      <td>92315</td>
      <td>34.244060</td>
      <td>-116.888382</td>
      <td>146</td>
      <td>112.03</td>
      <td>24</td>
    </tr>
    <tr>
      <th>24</th>
      <td>95203</td>
      <td>37.961437</td>
      <td>-121.299230</td>
      <td>169b</td>
      <td>4.01</td>
      <td>25</td>
    </tr>
    <tr>
      <th>25</th>
      <td>95948</td>
      <td>39.366966</td>
      <td>-121.690577</td>
      <td>9</td>
      <td>35.02</td>
      <td>26</td>
    </tr>
    <tr>
      <th>26</th>
      <td>92376</td>
      <td>34.103910</td>
      <td>-117.370486</td>
      <td>151h</td>
      <td>37.00</td>
      <td>27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>92335</td>
      <td>34.075913</td>
      <td>-117.435763</td>
      <td>151f</td>
      <td>33.01</td>
      <td>28</td>
    </tr>
    <tr>
      <th>28</th>
      <td>93514</td>
      <td>37.362022</td>
      <td>-118.418372</td>
      <td>53</td>
      <td>4.00</td>
      <td>29</td>
    </tr>
    <tr>
      <th>29</th>
      <td>92627</td>
      <td>33.649959</td>
      <td>-117.919049</td>
      <td>116p</td>
      <td>637.02</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1800</th>
      <td>94607</td>
      <td>37.799511</td>
      <td>-122.271239</td>
      <td>2c</td>
      <td>4030.00</td>
      <td>1801</td>
    </tr>
    <tr>
      <th>1801</th>
      <td>90255</td>
      <td>33.972891</td>
      <td>-118.212379</td>
      <td>78.2ccc</td>
      <td>5332.03</td>
      <td>1802</td>
    </tr>
    <tr>
      <th>1802</th>
      <td>90201</td>
      <td>33.969061</td>
      <td>-118.176068</td>
      <td>78.2ddd</td>
      <td>5338.05</td>
      <td>1803</td>
    </tr>
    <tr>
      <th>1803</th>
      <td>90095</td>
      <td>34.068908</td>
      <td>-118.445025</td>
      <td>78.2w</td>
      <td>2653.01</td>
      <td>1804</td>
    </tr>
    <tr>
      <th>1804</th>
      <td>94606</td>
      <td>37.789727</td>
      <td>-122.237990</td>
      <td>2c</td>
      <td>4059.02</td>
      <td>1805</td>
    </tr>
    <tr>
      <th>1805</th>
      <td>95407</td>
      <td>38.429307</td>
      <td>-122.741560</td>
      <td>210.1</td>
      <td>1531.04</td>
      <td>1806</td>
    </tr>
    <tr>
      <th>1806</th>
      <td>91605</td>
      <td>34.215715</td>
      <td>-118.396526</td>
      <td>78.2ppp</td>
      <td>1210.20</td>
      <td>1807</td>
    </tr>
    <tr>
      <th>1807</th>
      <td>91303</td>
      <td>34.201103</td>
      <td>-118.590600</td>
      <td>78.2hhhh</td>
      <td>1340.01</td>
      <td>1808</td>
    </tr>
    <tr>
      <th>1808</th>
      <td>91406</td>
      <td>34.193904</td>
      <td>-118.482831</td>
      <td>78.2cc</td>
      <td>1276.05</td>
      <td>1809</td>
    </tr>
    <tr>
      <th>1809</th>
      <td>91764</td>
      <td>34.068248</td>
      <td>-117.642495</td>
      <td>151c</td>
      <td>15.01</td>
      <td>1810</td>
    </tr>
    <tr>
      <th>1810</th>
      <td>90022</td>
      <td>34.034141</td>
      <td>-118.160915</td>
      <td>78.2d</td>
      <td>5304.00</td>
      <td>1811</td>
    </tr>
    <tr>
      <th>1811</th>
      <td>91710</td>
      <td>34.040964</td>
      <td>-117.689596</td>
      <td>151l</td>
      <td>4.04</td>
      <td>1812</td>
    </tr>
    <tr>
      <th>1812</th>
      <td>92382</td>
      <td>34.206947</td>
      <td>-117.152437</td>
      <td>146</td>
      <td>111.01</td>
      <td>1813</td>
    </tr>
    <tr>
      <th>1813</th>
      <td>90011</td>
      <td>34.003304</td>
      <td>-118.256479</td>
      <td>78.2ggg</td>
      <td>2286.00</td>
      <td>1814</td>
    </tr>
    <tr>
      <th>1814</th>
      <td>90037</td>
      <td>34.010416</td>
      <td>-118.274009</td>
      <td>78.2l</td>
      <td>2318.00</td>
      <td>1815</td>
    </tr>
    <tr>
      <th>1815</th>
      <td>93460</td>
      <td>34.606060</td>
      <td>-120.093733</td>
      <td>178.1</td>
      <td>19.06</td>
      <td>1816</td>
    </tr>
    <tr>
      <th>1816</th>
      <td>90029</td>
      <td>34.087012</td>
      <td>-118.291710</td>
      <td>78.2g</td>
      <td>1914.10</td>
      <td>1817</td>
    </tr>
    <tr>
      <th>1817</th>
      <td>90028</td>
      <td>34.101663</td>
      <td>-118.321100</td>
      <td>78.2a</td>
      <td>1910.00</td>
      <td>1818</td>
    </tr>
    <tr>
      <th>1818</th>
      <td>90038</td>
      <td>34.083520</td>
      <td>-118.313671</td>
      <td>78.2g</td>
      <td>1917.10</td>
      <td>1819</td>
    </tr>
    <tr>
      <th>1819</th>
      <td>90048</td>
      <td>34.076063</td>
      <td>-118.373295</td>
      <td>78.2f</td>
      <td>1945.00</td>
      <td>1820</td>
    </tr>
    <tr>
      <th>1820</th>
      <td>93622</td>
      <td>36.860624</td>
      <td>-120.458268</td>
      <td>25</td>
      <td>84.01</td>
      <td>1821</td>
    </tr>
    <tr>
      <th>1821</th>
      <td>92410</td>
      <td>34.097379</td>
      <td>-117.298641</td>
      <td>151g</td>
      <td>57.01</td>
      <td>1822</td>
    </tr>
    <tr>
      <th>1822</th>
      <td>95815</td>
      <td>38.610077</td>
      <td>-121.450815</td>
      <td>139j</td>
      <td>69.00</td>
      <td>1823</td>
    </tr>
    <tr>
      <th>1823</th>
      <td>95823</td>
      <td>38.493421</td>
      <td>-121.437707</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1824</td>
    </tr>
    <tr>
      <th>1824</th>
      <td>95823</td>
      <td>38.493662</td>
      <td>-121.440792</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1825</td>
    </tr>
    <tr>
      <th>1825</th>
      <td>95811</td>
      <td>38.576631</td>
      <td>-121.479589</td>
      <td>139j</td>
      <td>11.01</td>
      <td>1826</td>
    </tr>
    <tr>
      <th>1826</th>
      <td>92692</td>
      <td>33.557040</td>
      <td>-117.667255</td>
      <td>115.2a</td>
      <td>320.22</td>
      <td>1827</td>
    </tr>
    <tr>
      <th>1827</th>
      <td>92801</td>
      <td>33.850820</td>
      <td>-117.941811</td>
      <td>116l</td>
      <td>867.01</td>
      <td>1828</td>
    </tr>
    <tr>
      <th>1828</th>
      <td>92701</td>
      <td>33.759898</td>
      <td>-117.853557</td>
      <td>116h</td>
      <td>754.03</td>
      <td>1829</td>
    </tr>
    <tr>
      <th>1829</th>
      <td>90232</td>
      <td>34.020459</td>
      <td>-118.400917</td>
      <td>78.2y</td>
      <td>2699.05</td>
      <td>1830</td>
    </tr>
  </tbody>
</table>
<p>1830 rows × 6 columns</p>
</div>




```python
### Index list by zipcodes: zclist  NOTE: Doing this removed the column 'Provider_Address_Zip', not what you intended
zclist = df.set_index(['Provider_Address_Zip'])
```


```python
zclist
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Provider_Number</th>
      <th>NPI_Provider_Number</th>
      <th>Owner_Number</th>
      <th>Service_Location_Number</th>
      <th>Provider_Businness_Legal_Name</th>
      <th>Enrollment_Status_Effective_dat</th>
      <th>Provider_Type_Code</th>
      <th>Provider_Type_Code_Desc</th>
      <th>...</th>
      <th>Provider_Address_Attention_Line</th>
      <th>Provider_Address_Line_1</th>
      <th>Provider_Address_Line_2</th>
      <th>Provider_Address_City</th>
      <th>Provider_Address_State</th>
      <th>Provider_Address_Latitude</th>
      <th>Provider_Address_Longitude</th>
      <th>MSSA_ID</th>
      <th>TRACT_ID</th>
      <th>FID</th>
    </tr>
    <tr>
      <th>Provider_Address_Zip</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>90723</th>
      <td>-118.160002</td>
      <td>33.889872</td>
      <td>1518996313</td>
      <td>1518996313</td>
      <td>1</td>
      <td>1</td>
      <td>BEHROOZ YAGOOBIAN, MD</td>
      <td>1995-08-14T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>LATINO MEDICAL CENTER</td>
      <td>15730 PARAMOUNT BLVD</td>
      <td>NaN</td>
      <td>PARAMOUNT</td>
      <td>CA</td>
      <td>33.889872</td>
      <td>-118.160002</td>
      <td>78.2m</td>
      <td>5539.01</td>
      <td>1</td>
    </tr>
    <tr>
      <th>91205</th>
      <td>-118.239588</td>
      <td>34.137132</td>
      <td>1356362743</td>
      <td>1356362743</td>
      <td>1</td>
      <td>1</td>
      <td>COMPREHENSIVE COMM HLTH</td>
      <td>2006-12-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HEALTH CENTERS GLENDALE</td>
      <td>801 S CHEVY CHASE DR</td>
      <td>STE 250</td>
      <td>GLENDALE</td>
      <td>CA</td>
      <td>34.137132</td>
      <td>-118.239588</td>
      <td>78.2ff</td>
      <td>3021.02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.147588</td>
      <td>33.972803</td>
      <td>1184833501</td>
      <td>1184833501</td>
      <td>1</td>
      <td>1</td>
      <td>BELL GARDEN FAMILY</td>
      <td>2003-08-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>MEDICAL CENTER</td>
      <td>6501 GARFIELD AVE</td>
      <td>NaN</td>
      <td>BELL GARDENS</td>
      <td>CA</td>
      <td>33.972803</td>
      <td>-118.147588</td>
      <td>78.2c</td>
      <td>5339.02</td>
      <td>3</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>4</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>5</td>
    </tr>
    <tr>
      <th>90023</th>
      <td>-118.208139</td>
      <td>34.030985</td>
      <td>1710261284</td>
      <td>1710261284</td>
      <td>1</td>
      <td>1</td>
      <td>BELLA MEDICAL GROUP INC</td>
      <td>2012-03-26T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>2933 WHITTIER BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.030985</td>
      <td>-118.208139</td>
      <td>78.2h</td>
      <td>2047.00</td>
      <td>6</td>
    </tr>
    <tr>
      <th>90706</th>
      <td>-118.120765</td>
      <td>33.882105</td>
      <td>1932115375</td>
      <td>1932115375</td>
      <td>1</td>
      <td>1</td>
      <td>BELLFLOWER HEALTH CENTER</td>
      <td>1997-04-10T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>BELLFLOWER HEALTH CENTER</td>
      <td>10005 E FLOWER AVE</td>
      <td>NaN</td>
      <td>BELLFLOWER</td>
      <td>CA</td>
      <td>33.882105</td>
      <td>-118.120765</td>
      <td>78.2m</td>
      <td>5542.03</td>
      <td>7</td>
    </tr>
    <tr>
      <th>92335</th>
      <td>-117.435811</td>
      <td>34.103851</td>
      <td>1487742979</td>
      <td>1487742979</td>
      <td>1</td>
      <td>1</td>
      <td>BENNY J, GUZMAN, M.D., CORPO</td>
      <td>2003-09-04T07:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>8253 SIERRA AVE</td>
      <td>SUITE 200</td>
      <td>FONTANA</td>
      <td>CA</td>
      <td>34.103851</td>
      <td>-117.435811</td>
      <td>151h</td>
      <td>30.00</td>
      <td>8</td>
    </tr>
    <tr>
      <th>94704</th>
      <td>-122.269858</td>
      <td>37.863641</td>
      <td>1518963693</td>
      <td>1518963693</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PRIMARY CARE</td>
      <td>1996-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>BERKELEY PRIMARY CARE</td>
      <td>2001 DWIGHT WAY</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>37.863641</td>
      <td>-122.269858</td>
      <td>2a</td>
      <td>4235.00</td>
      <td>9</td>
    </tr>
    <tr>
      <th>94710</th>
      <td>-122.297686</td>
      <td>37.867938</td>
      <td>1902944796</td>
      <td>1902944796</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PUBLIC HLTH CLINIC</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>41</td>
      <td>COMMUNITY CLINIC</td>
      <td>...</td>
      <td>NaN</td>
      <td>830 UNIVERSITY AVE</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>10</td>
    </tr>
    <tr>
      <th>94710</th>
      <td>-122.297686</td>
      <td>37.867938</td>
      <td>1902944796</td>
      <td>1902944796</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PUBLIC HLTH CLINIC</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>NaN</td>
      <td>830 UNIVERSITY AVE</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>11</td>
    </tr>
    <tr>
      <th>92102</th>
      <td>-117.140230</td>
      <td>32.708729</td>
      <td>1861603151</td>
      <td>1861603151</td>
      <td>1</td>
      <td>1</td>
      <td>25TH ST FAMILY MEDICINE</td>
      <td>2007-07-23T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>25TH ST FAMILY MEDICINE</td>
      <td>316 25TH ST</td>
      <td>NaN</td>
      <td>SAN DIEGO</td>
      <td>CA</td>
      <td>32.708729</td>
      <td>-117.140230</td>
      <td>161c</td>
      <td>48.00</td>
      <td>12</td>
    </tr>
    <tr>
      <th>90255</th>
      <td>-118.220823</td>
      <td>33.973776</td>
      <td>1912928540</td>
      <td>1912928540</td>
      <td>1</td>
      <td>1</td>
      <td>BERNARDITA DE LOS REYES</td>
      <td>2000-04-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CLINICA SANTA ISABEL MED</td>
      <td>2760 E FLORENCE AVE</td>
      <td>NaN</td>
      <td>HUNTINGTON PARK</td>
      <td>CA</td>
      <td>33.973776</td>
      <td>-118.220823</td>
      <td>78.2ccc</td>
      <td>5331.07</td>
      <td>13</td>
    </tr>
    <tr>
      <th>93301</th>
      <td>-119.009485</td>
      <td>35.396189</td>
      <td>1588798870</td>
      <td>1588798870</td>
      <td>1</td>
      <td>1</td>
      <td>34TH STREET COMMUNITY HEALTH</td>
      <td>1997-02-05T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>2000 PHYSICIANS BLVD</td>
      <td>NaN</td>
      <td>BAKERSFIELD</td>
      <td>CA</td>
      <td>35.396189</td>
      <td>-119.009485</td>
      <td>66a</td>
      <td>6.00</td>
      <td>14</td>
    </tr>
    <tr>
      <th>90057</th>
      <td>-118.275105</td>
      <td>34.055679</td>
      <td>1689978850</td>
      <td>1689978850</td>
      <td>1</td>
      <td>1</td>
      <td>7TH ST MEDICAL GROUP</td>
      <td>2011-03-22T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>GROUP INC</td>
      <td>1919 W 7TH ST</td>
      <td>STE 2A</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.055679</td>
      <td>-118.275105</td>
      <td>78.2b</td>
      <td>2094.02</td>
      <td>15</td>
    </tr>
    <tr>
      <th>92103</th>
      <td>-117.161281</td>
      <td>32.740195</td>
      <td>1568800100</td>
      <td>1568800100</td>
      <td>1</td>
      <td>1</td>
      <td>BEST START MIDWIFE SERVICES</td>
      <td>2015-02-02T08:00:00.000Z</td>
      <td>5</td>
      <td>CERTIFIED NURSE MIDWIFE</td>
      <td>...</td>
      <td>NaN</td>
      <td>3343 4TH AVE</td>
      <td>NaN</td>
      <td>SAN DIEGO</td>
      <td>CA</td>
      <td>32.740195</td>
      <td>-117.161281</td>
      <td>161e</td>
      <td>60.00</td>
      <td>16</td>
    </tr>
    <tr>
      <th>90640</th>
      <td>-118.100423</td>
      <td>34.016047</td>
      <td>1184628919</td>
      <td>1184628919</td>
      <td>1</td>
      <td>1</td>
      <td>BEVERLY HOSPITAL</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>15</td>
      <td>COMMUNITY OUTPATIENT HOSPITAL</td>
      <td>...</td>
      <td>NaN</td>
      <td>309 W BEVERLY BLVD</td>
      <td>NaN</td>
      <td>MONTEBELLO</td>
      <td>CA</td>
      <td>34.016047</td>
      <td>-118.100423</td>
      <td>78.2nn</td>
      <td>5300.04</td>
      <td>17</td>
    </tr>
    <tr>
      <th>91605</th>
      <td>-118.387784</td>
      <td>34.205963</td>
      <td>1396067500</td>
      <td>1396067500</td>
      <td>1</td>
      <td>1</td>
      <td>AAA COMPREHENSIVE HEALTHCARE</td>
      <td>2010-04-30T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>7451 N LANKERSHIM BLVD</td>
      <td>NaN</td>
      <td>NORTH HOLLYWOOD</td>
      <td>CA</td>
      <td>34.205963</td>
      <td>-118.387784</td>
      <td>78.2bb</td>
      <td>1224.10</td>
      <td>18</td>
    </tr>
    <tr>
      <th>90260</th>
      <td>-118.352348</td>
      <td>33.878380</td>
      <td>1629192133</td>
      <td>1629192133</td>
      <td>1</td>
      <td>1</td>
      <td>BEVERLY, SHEREEN L MD</td>
      <td>1990-02-28T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>INC</td>
      <td>16812 HAWTHORNE BLVD</td>
      <td>NaN</td>
      <td>LAWNDALE</td>
      <td>CA</td>
      <td>33.878380</td>
      <td>-118.352348</td>
      <td>78.2iiii</td>
      <td>6041.00</td>
      <td>19</td>
    </tr>
    <tr>
      <th>90001</th>
      <td>-118.256403</td>
      <td>33.961796</td>
      <td>1316061674</td>
      <td>1316061674</td>
      <td>1</td>
      <td>1</td>
      <td>ABAIAN, ALI MD</td>
      <td>2001-04-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>8460 S CENTRAL AVENUE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>33.961796</td>
      <td>-118.256403</td>
      <td>78.2fff</td>
      <td>2398.02</td>
      <td>20</td>
    </tr>
    <tr>
      <th>92701</th>
      <td>-117.854493</td>
      <td>33.759883</td>
      <td>1861680712</td>
      <td>1861680712</td>
      <td>1</td>
      <td>1</td>
      <td>BIENESTAR MEDICAL CENTER</td>
      <td>2006-11-02T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>INC</td>
      <td>1125 E 17TH STREET</td>
      <td>SUITE N 152</td>
      <td>SANTA ANA</td>
      <td>CA</td>
      <td>33.759883</td>
      <td>-117.854493</td>
      <td>116h</td>
      <td>754.03</td>
      <td>21</td>
    </tr>
    <tr>
      <th>92201</th>
      <td>-116.239207</td>
      <td>33.707410</td>
      <td>1043281108</td>
      <td>1043281108</td>
      <td>1</td>
      <td>1</td>
      <td>ABHYANKAR, S.R. MD PC</td>
      <td>2006-04-11T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>81-709 DR CARREON BLVD</td>
      <td>STE C1</td>
      <td>INDIO</td>
      <td>CA</td>
      <td>33.707410</td>
      <td>-116.239207</td>
      <td>128</td>
      <td>452.07</td>
      <td>22</td>
    </tr>
    <tr>
      <th>90022</th>
      <td>-118.155282</td>
      <td>34.026948</td>
      <td>1497001226</td>
      <td>1497001226</td>
      <td>1</td>
      <td>1</td>
      <td>BIENVENIDOS COMMUNITY HEALTH</td>
      <td>2013-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>INC</td>
      <td>507 S. ATLANTIC BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.026948</td>
      <td>-118.155282</td>
      <td>78.2d</td>
      <td>5303.01</td>
      <td>23</td>
    </tr>
    <tr>
      <th>92315</th>
      <td>-116.888382</td>
      <td>34.244060</td>
      <td>1578535845</td>
      <td>1578535845</td>
      <td>1</td>
      <td>5</td>
      <td>BIG BEAR PUBLIC HEALTH CLINI</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>NaN</td>
      <td>477 SUMMIT BLVD</td>
      <td>NaN</td>
      <td>BIG BEAR LAKE</td>
      <td>CA</td>
      <td>34.244060</td>
      <td>-116.888382</td>
      <td>146</td>
      <td>112.03</td>
      <td>24</td>
    </tr>
    <tr>
      <th>95203</th>
      <td>-121.299230</td>
      <td>37.961437</td>
      <td>1073619060</td>
      <td>1073619060</td>
      <td>1</td>
      <td>1</td>
      <td>BIG VALLEY OB-GYN MEDICAL</td>
      <td>1988-01-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>CENTER INC</td>
      <td>420 W ACACIA ST</td>
      <td>STE 11</td>
      <td>STOCKTON</td>
      <td>CA</td>
      <td>37.961437</td>
      <td>-121.299230</td>
      <td>169b</td>
      <td>4.01</td>
      <td>25</td>
    </tr>
    <tr>
      <th>95948</th>
      <td>-121.690577</td>
      <td>39.366966</td>
      <td>1578708285</td>
      <td>1578708285</td>
      <td>1</td>
      <td>1</td>
      <td>BIGGS GRIDLEY HOSP</td>
      <td>1998-10-13T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>FAMILY CARE CTR</td>
      <td>240 SPRUCE ST</td>
      <td>NaN</td>
      <td>GRIDLEY</td>
      <td>CA</td>
      <td>39.366966</td>
      <td>-121.690577</td>
      <td>9</td>
      <td>35.02</td>
      <td>26</td>
    </tr>
    <tr>
      <th>92376</th>
      <td>-117.370486</td>
      <td>34.103910</td>
      <td>1275656761</td>
      <td>1275656761</td>
      <td>1</td>
      <td>1</td>
      <td>BIR, RAGHBIR S MD</td>
      <td>1998-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>280 N RIVERSIDE AVE</td>
      <td>NaN</td>
      <td>RIALTO</td>
      <td>CA</td>
      <td>34.103910</td>
      <td>-117.370486</td>
      <td>151h</td>
      <td>37.00</td>
      <td>27</td>
    </tr>
    <tr>
      <th>92335</th>
      <td>-117.435763</td>
      <td>34.075913</td>
      <td>1568585024</td>
      <td>1568585024</td>
      <td>1</td>
      <td>1</td>
      <td>BIR, RAGHBIR S MD</td>
      <td>2001-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>9792 SIERRA AVE</td>
      <td>NaN</td>
      <td>FONTANA</td>
      <td>CA</td>
      <td>34.075913</td>
      <td>-117.435763</td>
      <td>151f</td>
      <td>33.01</td>
      <td>28</td>
    </tr>
    <tr>
      <th>93514</th>
      <td>-118.418372</td>
      <td>37.362022</td>
      <td>1659433191</td>
      <td>1659433191</td>
      <td>1</td>
      <td>3</td>
      <td>BISHOP CLINIC</td>
      <td>1991-11-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>BISHOP CLINIC</td>
      <td>52 TU SU LANE</td>
      <td>NaN</td>
      <td>BISHOP</td>
      <td>CA</td>
      <td>37.362022</td>
      <td>-118.418372</td>
      <td>53</td>
      <td>4.00</td>
      <td>29</td>
    </tr>
    <tr>
      <th>92627</th>
      <td>-117.919049</td>
      <td>33.649959</td>
      <td>1841419793</td>
      <td>1841419793</td>
      <td>1</td>
      <td>1</td>
      <td>BLACK, ROBIN</td>
      <td>2007-02-07T08:00:00.000Z</td>
      <td>7</td>
      <td>CERTIFIED NURSE PRACTIONER</td>
      <td>...</td>
      <td>NaN</td>
      <td>2077 HARBOR BLVD</td>
      <td>STE C</td>
      <td>COSTA MESA</td>
      <td>CA</td>
      <td>33.649959</td>
      <td>-117.919049</td>
      <td>116p</td>
      <td>637.02</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>94607</th>
      <td>-122.271239</td>
      <td>37.799511</td>
      <td>1225179641</td>
      <td>1225179641</td>
      <td>1</td>
      <td>1</td>
      <td>ROLLAND AND KATHRYN LOWE MED</td>
      <td>1996-10-23T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>835 WEBSTER ST</td>
      <td>NaN</td>
      <td>OAKLAND</td>
      <td>CA</td>
      <td>37.799511</td>
      <td>-122.271239</td>
      <td>2c</td>
      <td>4030.00</td>
      <td>1801</td>
    </tr>
    <tr>
      <th>90255</th>
      <td>-118.212379</td>
      <td>33.972891</td>
      <td>1114032208</td>
      <td>1114032208</td>
      <td>1</td>
      <td>1</td>
      <td>ROMERO, JESUSA N MD APC</td>
      <td>1988-12-31T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>3100 E FLORENCE AVE</td>
      <td>STE 5</td>
      <td>HUNTINGTON PARK</td>
      <td>CA</td>
      <td>33.972891</td>
      <td>-118.212379</td>
      <td>78.2ccc</td>
      <td>5332.03</td>
      <td>1802</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.176068</td>
      <td>33.969061</td>
      <td>1861576480</td>
      <td>1861576480</td>
      <td>1</td>
      <td>1</td>
      <td>ROMO, MARY S MD INC</td>
      <td>1991-12-31T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>5101 FLORENCE AVE</td>
      <td>STE 5</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.969061</td>
      <td>-118.176068</td>
      <td>78.2ddd</td>
      <td>5338.05</td>
      <td>1803</td>
    </tr>
    <tr>
      <th>90095</th>
      <td>-118.445025</td>
      <td>34.068908</td>
      <td>1902803315</td>
      <td>1902803315</td>
      <td>1</td>
      <td>1</td>
      <td>RONALD REAGAN UCLA MED</td>
      <td>2005-07-01T07:00:00.000Z</td>
      <td>15</td>
      <td>COMMUNITY OUTPATIENT HOSPITAL</td>
      <td>...</td>
      <td>CALIFORNIA</td>
      <td>757 WESTWOOD PLAZA</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.068908</td>
      <td>-118.445025</td>
      <td>78.2w</td>
      <td>2653.01</td>
      <td>1804</td>
    </tr>
    <tr>
      <th>94606</th>
      <td>-122.237990</td>
      <td>37.789727</td>
      <td>1851522015</td>
      <td>1851522015</td>
      <td>1</td>
      <td>1</td>
      <td>ROOSEVELT HEALTH CENTER</td>
      <td>2009-11-12T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>1926 19TH AVE</td>
      <td>NaN</td>
      <td>OAKLAND</td>
      <td>CA</td>
      <td>37.789727</td>
      <td>-122.237990</td>
      <td>2c</td>
      <td>4059.02</td>
      <td>1805</td>
    </tr>
    <tr>
      <th>95407</th>
      <td>-122.741560</td>
      <td>38.429307</td>
      <td>1558512624</td>
      <td>1558512624</td>
      <td>1</td>
      <td>1</td>
      <td>ROSELAND PEDIATRICS</td>
      <td>2008-09-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>711 STONY POINT ROAD</td>
      <td>SUITE 17</td>
      <td>SANTA ROSA</td>
      <td>CA</td>
      <td>38.429307</td>
      <td>-122.741560</td>
      <td>210.1</td>
      <td>1531.04</td>
      <td>1806</td>
    </tr>
    <tr>
      <th>91605</th>
      <td>-118.396526</td>
      <td>34.215715</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>5</td>
      <td>ROY MEDICAL GROUP INC</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>8001 LAUREL CANYON BLVD</td>
      <td>STE 109</td>
      <td>NORTH HOLLYWOOD</td>
      <td>CA</td>
      <td>34.215715</td>
      <td>-118.396526</td>
      <td>78.2ppp</td>
      <td>1210.20</td>
      <td>1807</td>
    </tr>
    <tr>
      <th>91303</th>
      <td>-118.590600</td>
      <td>34.201103</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>1</td>
      <td>ROY, ROSALINDA A MD</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>21001 SHERMAN WAY</td>
      <td>STE 15</td>
      <td>CANOGA PARK</td>
      <td>CA</td>
      <td>34.201103</td>
      <td>-118.590600</td>
      <td>78.2hhhh</td>
      <td>1340.01</td>
      <td>1808</td>
    </tr>
    <tr>
      <th>91406</th>
      <td>-118.482831</td>
      <td>34.193904</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>2</td>
      <td>ROY, ROSALINDA A MD</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>16063 VANOWEN ST</td>
      <td>NaN</td>
      <td>VAN NUYS</td>
      <td>CA</td>
      <td>34.193904</td>
      <td>-118.482831</td>
      <td>78.2cc</td>
      <td>1276.05</td>
      <td>1809</td>
    </tr>
    <tr>
      <th>91764</th>
      <td>-117.642495</td>
      <td>34.068248</td>
      <td>1619144227</td>
      <td>1619144227</td>
      <td>1</td>
      <td>1</td>
      <td>ROYAL CARE MEDICAL CENTER</td>
      <td>2011-01-11T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CENTER INC</td>
      <td>653 E E ST</td>
      <td>STE 109</td>
      <td>ONTARIO</td>
      <td>CA</td>
      <td>34.068248</td>
      <td>-117.642495</td>
      <td>151c</td>
      <td>15.01</td>
      <td>1810</td>
    </tr>
    <tr>
      <th>90022</th>
      <td>-118.160915</td>
      <td>34.034141</td>
      <td>1083627749</td>
      <td>1083627749</td>
      <td>1</td>
      <td>1</td>
      <td>ROYBAL COMPREHENSIVE HLT</td>
      <td>1997-04-10T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>ROYBAL COMPREHENSIVE HLT</td>
      <td>245 S FETTERLY AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.034141</td>
      <td>-118.160915</td>
      <td>78.2d</td>
      <td>5304.00</td>
      <td>1811</td>
    </tr>
    <tr>
      <th>91710</th>
      <td>-117.689596</td>
      <td>34.040964</td>
      <td>1740303247</td>
      <td>1740303247</td>
      <td>1</td>
      <td>1</td>
      <td>RS BIR MD INC CLINICA MEDIC</td>
      <td>1998-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>11692 CENTRAL AVE</td>
      <td>NaN</td>
      <td>CHINO</td>
      <td>CA</td>
      <td>34.040964</td>
      <td>-117.689596</td>
      <td>151l</td>
      <td>4.04</td>
      <td>1812</td>
    </tr>
    <tr>
      <th>92382</th>
      <td>-117.152437</td>
      <td>34.206947</td>
      <td>1881703957</td>
      <td>1881703957</td>
      <td>1</td>
      <td>1</td>
      <td>RURAL HEALTH CLINIC</td>
      <td>2008-01-09T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>COMMUNITAL HOSPITAL DIST</td>
      <td>31900 HILLTOP BLVD</td>
      <td>NaN</td>
      <td>RUNNING SPRINGS</td>
      <td>CA</td>
      <td>34.206947</td>
      <td>-117.152437</td>
      <td>146</td>
      <td>111.01</td>
      <td>1813</td>
    </tr>
    <tr>
      <th>90011</th>
      <td>-118.256479</td>
      <td>34.003304</td>
      <td>1396891909</td>
      <td>1396891909</td>
      <td>1</td>
      <td>1</td>
      <td>S CENTRAL FAMILY HLTH CT</td>
      <td>1994-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HEALTH CTR</td>
      <td>4425 S CENTRAL AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.003304</td>
      <td>-118.256479</td>
      <td>78.2ggg</td>
      <td>2286.00</td>
      <td>1814</td>
    </tr>
    <tr>
      <th>90037</th>
      <td>-118.274009</td>
      <td>34.010416</td>
      <td>1487923306</td>
      <td>1487923306</td>
      <td>1</td>
      <td>1</td>
      <td>S MARK TAPER FNDN HEALTH</td>
      <td>2012-03-09T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>4000 S MAIN STREET</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.010416</td>
      <td>-118.274009</td>
      <td>78.2l</td>
      <td>2318.00</td>
      <td>1815</td>
    </tr>
    <tr>
      <th>93460</th>
      <td>-120.093733</td>
      <td>34.606060</td>
      <td>1992779417</td>
      <td>1992779417</td>
      <td>1</td>
      <td>1</td>
      <td>S Y BAND OF MISSION IND</td>
      <td>1991-09-27T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>CLINIC</td>
      <td>90 VIA JUANA RD</td>
      <td>NaN</td>
      <td>SANTA YNEZ</td>
      <td>CA</td>
      <td>34.606060</td>
      <td>-120.093733</td>
      <td>178.1</td>
      <td>19.06</td>
      <td>1816</td>
    </tr>
    <tr>
      <th>90029</th>
      <td>-118.291710</td>
      <td>34.087012</td>
      <td>1891806329</td>
      <td>1891806329</td>
      <td>1</td>
      <td>2</td>
      <td>SABABA, LILIAN E MD</td>
      <td>1991-02-28T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>866 N VERMONT AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.087012</td>
      <td>-118.291710</td>
      <td>78.2g</td>
      <td>1914.10</td>
      <td>1817</td>
    </tr>
    <tr>
      <th>90028</th>
      <td>-118.321100</td>
      <td>34.101663</td>
      <td>1235271065</td>
      <td>1235271065</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN COMMUNITY CLINIC</td>
      <td>1997-06-24T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HOLLYWOOD HEALTH CENTER</td>
      <td>6043 HOLLYWOOD BLVD</td>
      <td>NaN</td>
      <td>HOLLYWOOD</td>
      <td>CA</td>
      <td>34.101663</td>
      <td>-118.321100</td>
      <td>78.2a</td>
      <td>1910.00</td>
      <td>1818</td>
    </tr>
    <tr>
      <th>90038</th>
      <td>-118.313671</td>
      <td>34.083520</td>
      <td>1336281179</td>
      <td>1336281179</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN COMMUNITY CLINIC</td>
      <td>2002-04-17T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HOLLYWOOD WILSHIRE HLTH</td>
      <td>5205 MELROSE AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.083520</td>
      <td>-118.313671</td>
      <td>78.2g</td>
      <td>1917.10</td>
      <td>1819</td>
    </tr>
    <tr>
      <th>90048</th>
      <td>-118.373295</td>
      <td>34.076063</td>
      <td>1194893248</td>
      <td>1194893248</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN FREE CLINIC BEVERLY</td>
      <td>1994-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>8405 BEVERLY BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.076063</td>
      <td>-118.373295</td>
      <td>78.2f</td>
      <td>1945.00</td>
      <td>1820</td>
    </tr>
    <tr>
      <th>93622</th>
      <td>-120.458268</td>
      <td>36.860624</td>
      <td>1558638601</td>
      <td>1558638601</td>
      <td>1</td>
      <td>1</td>
      <td>SABLAN HEALTH CENTER</td>
      <td>2012-03-12T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>927 O STREET</td>
      <td>NaN</td>
      <td>FIREBAUGH</td>
      <td>CA</td>
      <td>36.860624</td>
      <td>-120.458268</td>
      <td>25</td>
      <td>84.01</td>
      <td>1821</td>
    </tr>
    <tr>
      <th>92410</th>
      <td>-117.298641</td>
      <td>34.097379</td>
      <td>1801270137</td>
      <td>1801270137</td>
      <td>1</td>
      <td>1</td>
      <td>SAC SAN BERNARDINO CAMPUS</td>
      <td>2016-07-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>250 SOUTH G STREET</td>
      <td>NaN</td>
      <td>SAN BERNARDINO</td>
      <td>CA</td>
      <td>34.097379</td>
      <td>-117.298641</td>
      <td>151g</td>
      <td>57.01</td>
      <td>1822</td>
    </tr>
    <tr>
      <th>95815</th>
      <td>-121.450815</td>
      <td>38.610077</td>
      <td>1538180245</td>
      <td>1538180245</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMM CLINIC</td>
      <td>2006-11-22T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>ORGANIZATION INC</td>
      <td>2200 DEL PASO BLVD</td>
      <td>NaN</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.610077</td>
      <td>-121.450815</td>
      <td>139j</td>
      <td>69.00</td>
      <td>1823</td>
    </tr>
    <tr>
      <th>95823</th>
      <td>-121.437707</td>
      <td>38.493421</td>
      <td>1740336734</td>
      <td>1740336734</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMM CLINIC</td>
      <td>2006-11-21T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>ORGANIZATION INC</td>
      <td>7275 E SOUTHGATE DR</td>
      <td>STE 204-206</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.493421</td>
      <td>-121.437707</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1824</td>
    </tr>
    <tr>
      <th>95823</th>
      <td>-121.440792</td>
      <td>38.493662</td>
      <td>1295044832</td>
      <td>1295044832</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMMUNITY CLINIC</td>
      <td>2012-02-22T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>INC</td>
      <td>5524 ASSEMBLY COURT</td>
      <td>SUITE 200</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.493662</td>
      <td>-121.440792</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1825</td>
    </tr>
    <tr>
      <th>95811</th>
      <td>-121.479589</td>
      <td>38.576631</td>
      <td>1588756530</td>
      <td>1588756530</td>
      <td>1</td>
      <td>3</td>
      <td>SACRAMENTO NATIVE AMER</td>
      <td>2006-12-20T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>AMERICAN HEALTH CTR, INC</td>
      <td>2020 J ST</td>
      <td>NaN</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.576631</td>
      <td>-121.479589</td>
      <td>139j</td>
      <td>11.01</td>
      <td>1826</td>
    </tr>
    <tr>
      <th>92692</th>
      <td>-117.667255</td>
      <td>33.557040</td>
      <td>1376905026</td>
      <td>1376905026</td>
      <td>1</td>
      <td>1</td>
      <td>SADDLEBACK COLLEGE</td>
      <td>2016-05-18T07:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>COMMUNITY COLLEGE DISTRI</td>
      <td>28000 MARGUERITE PARKWAY</td>
      <td>NaN</td>
      <td>MISSION VIEJO</td>
      <td>CA</td>
      <td>33.557040</td>
      <td>-117.667255</td>
      <td>115.2a</td>
      <td>320.22</td>
      <td>1827</td>
    </tr>
    <tr>
      <th>92801</th>
      <td>-117.941811</td>
      <td>33.850820</td>
      <td>1124296496</td>
      <td>1124296496</td>
      <td>1</td>
      <td>1</td>
      <td>SAENZ, LUCY M MD</td>
      <td>2002-12-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>1203 N EUCLID ST</td>
      <td>NaN</td>
      <td>ANAHEIM</td>
      <td>CA</td>
      <td>33.850820</td>
      <td>-117.941811</td>
      <td>116l</td>
      <td>867.01</td>
      <td>1828</td>
    </tr>
    <tr>
      <th>92701</th>
      <td>-117.853557</td>
      <td>33.759898</td>
      <td>1548367436</td>
      <td>1548367436</td>
      <td>1</td>
      <td>1</td>
      <td>SAENZ, LUCY M MD INC</td>
      <td>1998-05-01T07:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>1215 E 17TH ST</td>
      <td>NaN</td>
      <td>SANTA ANA</td>
      <td>CA</td>
      <td>33.759898</td>
      <td>-117.853557</td>
      <td>116h</td>
      <td>754.03</td>
      <td>1829</td>
    </tr>
    <tr>
      <th>90232</th>
      <td>-118.400917</td>
      <td>34.020459</td>
      <td>1306945241</td>
      <td>1306945241</td>
      <td>1</td>
      <td>1</td>
      <td>SAINT ANA WOMEN MED CLNC</td>
      <td>1999-02-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>SAINT ANA WOMEN MED CLNC</td>
      <td>3865 JASMINE AVE</td>
      <td>NaN</td>
      <td>CULVER CITY</td>
      <td>CA</td>
      <td>34.020459</td>
      <td>-118.400917</td>
      <td>78.2y</td>
      <td>2699.05</td>
      <td>1830</td>
    </tr>
  </tbody>
</table>
<p>1830 rows × 27 columns</p>
</div>




```python
zclist.columns
```




    Index(['X', 'Y', 'Provider_Number', 'NPI_Provider_Number', 'Owner_Number',
           'Service_Location_Number', 'Provider_Businness_Legal_Name',
           'Enrollment_Status_Effective_dat', 'Provider_Type_Code',
           'Provider_Type_Code_Desc', 'Provider_License_Number',
           'Provider_Specialty_Code', 'Provider_Specialty_Code_Desc',
           'Out_of_State_Ind', 'Out_of_State_Desc', 'Provider_Address_County_Code',
           'Provider_Address_County_Code_De', 'Provider_Address_Attention_Line',
           'Provider_Address_Line_1', 'Provider_Address_Line_2',
           'Provider_Address_City', 'Provider_Address_State',
           'Provider_Address_Latitude', 'Provider_Address_Longitude', 'MSSA_ID',
           'TRACT_ID', 'FID'],
          dtype='object')




```python
zclist.shape
```




    (1830, 27)




```python
zclist.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1830 entries, 90723 to 90232
    Data columns (total 27 columns):
    X                                  1830 non-null float64
    Y                                  1830 non-null float64
    Provider_Number                    1830 non-null int64
    NPI_Provider_Number                1830 non-null int64
    Owner_Number                       1830 non-null int64
    Service_Location_Number            1830 non-null int64
    Provider_Businness_Legal_Name      1830 non-null object
    Enrollment_Status_Effective_dat    1830 non-null object
    Provider_Type_Code                 1830 non-null int64
    Provider_Type_Code_Desc            1636 non-null object
    Provider_License_Number            685 non-null object
    Provider_Specialty_Code            633 non-null float64
    Provider_Specialty_Code_Desc       502 non-null object
    Out_of_State_Ind                   1830 non-null int64
    Out_of_State_Desc                  1830 non-null object
    Provider_Address_County_Code       1829 non-null float64
    Provider_Address_County_Code_De    1829 non-null object
    Provider_Address_Attention_Line    1017 non-null object
    Provider_Address_Line_1            1830 non-null object
    Provider_Address_Line_2            632 non-null object
    Provider_Address_City              1830 non-null object
    Provider_Address_State             1830 non-null object
    Provider_Address_Latitude          1830 non-null float64
    Provider_Address_Longitude         1830 non-null float64
    MSSA_ID                            1830 non-null object
    TRACT_ID                           1830 non-null float64
    FID                                1830 non-null int64
    dtypes: float64(7), int64(7), object(13)
    memory usage: 400.3+ KB
    


```python
type(zclist.columns)
```




    pandas.core.indexes.base.Index




```python
zclist.index
```




    Int64Index([90723, 91205, 90201, 90201, 90201, 90023, 90706, 92335, 94704,
                94710,
                ...
                93622, 92410, 95815, 95823, 95823, 95811, 92692, 92801, 92701,
                90232],
               dtype='int64', name='Provider_Address_Zip', length=1830)




```python
zclist.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Provider_Number</th>
      <th>NPI_Provider_Number</th>
      <th>Owner_Number</th>
      <th>Service_Location_Number</th>
      <th>Provider_Businness_Legal_Name</th>
      <th>Enrollment_Status_Effective_dat</th>
      <th>Provider_Type_Code</th>
      <th>Provider_Type_Code_Desc</th>
      <th>...</th>
      <th>Provider_Address_Attention_Line</th>
      <th>Provider_Address_Line_1</th>
      <th>Provider_Address_Line_2</th>
      <th>Provider_Address_City</th>
      <th>Provider_Address_State</th>
      <th>Provider_Address_Latitude</th>
      <th>Provider_Address_Longitude</th>
      <th>MSSA_ID</th>
      <th>TRACT_ID</th>
      <th>FID</th>
    </tr>
    <tr>
      <th>Provider_Address_Zip</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>90723</th>
      <td>-118.160002</td>
      <td>33.889872</td>
      <td>1518996313</td>
      <td>1518996313</td>
      <td>1</td>
      <td>1</td>
      <td>BEHROOZ YAGOOBIAN, MD</td>
      <td>1995-08-14T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>LATINO MEDICAL CENTER</td>
      <td>15730 PARAMOUNT BLVD</td>
      <td>NaN</td>
      <td>PARAMOUNT</td>
      <td>CA</td>
      <td>33.889872</td>
      <td>-118.160002</td>
      <td>78.2m</td>
      <td>5539.01</td>
      <td>1</td>
    </tr>
    <tr>
      <th>91205</th>
      <td>-118.239588</td>
      <td>34.137132</td>
      <td>1356362743</td>
      <td>1356362743</td>
      <td>1</td>
      <td>1</td>
      <td>COMPREHENSIVE COMM HLTH</td>
      <td>2006-12-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HEALTH CENTERS GLENDALE</td>
      <td>801 S CHEVY CHASE DR</td>
      <td>STE 250</td>
      <td>GLENDALE</td>
      <td>CA</td>
      <td>34.137132</td>
      <td>-118.239588</td>
      <td>78.2ff</td>
      <td>3021.02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.147588</td>
      <td>33.972803</td>
      <td>1184833501</td>
      <td>1184833501</td>
      <td>1</td>
      <td>1</td>
      <td>BELL GARDEN FAMILY</td>
      <td>2003-08-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>MEDICAL CENTER</td>
      <td>6501 GARFIELD AVE</td>
      <td>NaN</td>
      <td>BELL GARDENS</td>
      <td>CA</td>
      <td>33.972803</td>
      <td>-118.147588</td>
      <td>78.2c</td>
      <td>5339.02</td>
      <td>3</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>4</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>




```python
zclist.iloc[:,:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Provider_Number</th>
      <th>NPI_Provider_Number</th>
      <th>Owner_Number</th>
      <th>Service_Location_Number</th>
      <th>Provider_Businness_Legal_Name</th>
      <th>Enrollment_Status_Effective_dat</th>
      <th>Provider_Type_Code</th>
      <th>Provider_Type_Code_Desc</th>
      <th>...</th>
      <th>Provider_Address_Attention_Line</th>
      <th>Provider_Address_Line_1</th>
      <th>Provider_Address_Line_2</th>
      <th>Provider_Address_City</th>
      <th>Provider_Address_State</th>
      <th>Provider_Address_Latitude</th>
      <th>Provider_Address_Longitude</th>
      <th>MSSA_ID</th>
      <th>TRACT_ID</th>
      <th>FID</th>
    </tr>
    <tr>
      <th>Provider_Address_Zip</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>90723</th>
      <td>-118.160002</td>
      <td>33.889872</td>
      <td>1518996313</td>
      <td>1518996313</td>
      <td>1</td>
      <td>1</td>
      <td>BEHROOZ YAGOOBIAN, MD</td>
      <td>1995-08-14T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>LATINO MEDICAL CENTER</td>
      <td>15730 PARAMOUNT BLVD</td>
      <td>NaN</td>
      <td>PARAMOUNT</td>
      <td>CA</td>
      <td>33.889872</td>
      <td>-118.160002</td>
      <td>78.2m</td>
      <td>5539.01</td>
      <td>1</td>
    </tr>
    <tr>
      <th>91205</th>
      <td>-118.239588</td>
      <td>34.137132</td>
      <td>1356362743</td>
      <td>1356362743</td>
      <td>1</td>
      <td>1</td>
      <td>COMPREHENSIVE COMM HLTH</td>
      <td>2006-12-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HEALTH CENTERS GLENDALE</td>
      <td>801 S CHEVY CHASE DR</td>
      <td>STE 250</td>
      <td>GLENDALE</td>
      <td>CA</td>
      <td>34.137132</td>
      <td>-118.239588</td>
      <td>78.2ff</td>
      <td>3021.02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.147588</td>
      <td>33.972803</td>
      <td>1184833501</td>
      <td>1184833501</td>
      <td>1</td>
      <td>1</td>
      <td>BELL GARDEN FAMILY</td>
      <td>2003-08-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>MEDICAL CENTER</td>
      <td>6501 GARFIELD AVE</td>
      <td>NaN</td>
      <td>BELL GARDENS</td>
      <td>CA</td>
      <td>33.972803</td>
      <td>-118.147588</td>
      <td>78.2c</td>
      <td>5339.02</td>
      <td>3</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>4</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.179412</td>
      <td>33.977217</td>
      <td>1699767517</td>
      <td>1699767517</td>
      <td>2</td>
      <td>1</td>
      <td>BELL PLAZA MEDICAL CLINIC</td>
      <td>2013-05-13T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>4827 GAGE AVENUE</td>
      <td>NaN</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.977217</td>
      <td>-118.179412</td>
      <td>78.2ddd</td>
      <td>5338.04</td>
      <td>5</td>
    </tr>
    <tr>
      <th>90023</th>
      <td>-118.208139</td>
      <td>34.030985</td>
      <td>1710261284</td>
      <td>1710261284</td>
      <td>1</td>
      <td>1</td>
      <td>BELLA MEDICAL GROUP INC</td>
      <td>2012-03-26T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>2933 WHITTIER BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.030985</td>
      <td>-118.208139</td>
      <td>78.2h</td>
      <td>2047.00</td>
      <td>6</td>
    </tr>
    <tr>
      <th>90706</th>
      <td>-118.120765</td>
      <td>33.882105</td>
      <td>1932115375</td>
      <td>1932115375</td>
      <td>1</td>
      <td>1</td>
      <td>BELLFLOWER HEALTH CENTER</td>
      <td>1997-04-10T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>BELLFLOWER HEALTH CENTER</td>
      <td>10005 E FLOWER AVE</td>
      <td>NaN</td>
      <td>BELLFLOWER</td>
      <td>CA</td>
      <td>33.882105</td>
      <td>-118.120765</td>
      <td>78.2m</td>
      <td>5542.03</td>
      <td>7</td>
    </tr>
    <tr>
      <th>92335</th>
      <td>-117.435811</td>
      <td>34.103851</td>
      <td>1487742979</td>
      <td>1487742979</td>
      <td>1</td>
      <td>1</td>
      <td>BENNY J, GUZMAN, M.D., CORPO</td>
      <td>2003-09-04T07:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>CORPORATION</td>
      <td>8253 SIERRA AVE</td>
      <td>SUITE 200</td>
      <td>FONTANA</td>
      <td>CA</td>
      <td>34.103851</td>
      <td>-117.435811</td>
      <td>151h</td>
      <td>30.00</td>
      <td>8</td>
    </tr>
    <tr>
      <th>94704</th>
      <td>-122.269858</td>
      <td>37.863641</td>
      <td>1518963693</td>
      <td>1518963693</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PRIMARY CARE</td>
      <td>1996-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>BERKELEY PRIMARY CARE</td>
      <td>2001 DWIGHT WAY</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>37.863641</td>
      <td>-122.269858</td>
      <td>2a</td>
      <td>4235.00</td>
      <td>9</td>
    </tr>
    <tr>
      <th>94710</th>
      <td>-122.297686</td>
      <td>37.867938</td>
      <td>1902944796</td>
      <td>1902944796</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PUBLIC HLTH CLINIC</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>41</td>
      <td>COMMUNITY CLINIC</td>
      <td>...</td>
      <td>NaN</td>
      <td>830 UNIVERSITY AVE</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>10</td>
    </tr>
    <tr>
      <th>94710</th>
      <td>-122.297686</td>
      <td>37.867938</td>
      <td>1902944796</td>
      <td>1902944796</td>
      <td>1</td>
      <td>1</td>
      <td>BERKELEY PUBLIC HLTH CLINIC</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>NaN</td>
      <td>830 UNIVERSITY AVE</td>
      <td>NaN</td>
      <td>BERKELEY</td>
      <td>CA</td>
      <td>37.867938</td>
      <td>-122.297686</td>
      <td>2a</td>
      <td>4232.00</td>
      <td>11</td>
    </tr>
    <tr>
      <th>92102</th>
      <td>-117.140230</td>
      <td>32.708729</td>
      <td>1861603151</td>
      <td>1861603151</td>
      <td>1</td>
      <td>1</td>
      <td>25TH ST FAMILY MEDICINE</td>
      <td>2007-07-23T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>25TH ST FAMILY MEDICINE</td>
      <td>316 25TH ST</td>
      <td>NaN</td>
      <td>SAN DIEGO</td>
      <td>CA</td>
      <td>32.708729</td>
      <td>-117.140230</td>
      <td>161c</td>
      <td>48.00</td>
      <td>12</td>
    </tr>
    <tr>
      <th>90255</th>
      <td>-118.220823</td>
      <td>33.973776</td>
      <td>1912928540</td>
      <td>1912928540</td>
      <td>1</td>
      <td>1</td>
      <td>BERNARDITA DE LOS REYES</td>
      <td>2000-04-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CLINICA SANTA ISABEL MED</td>
      <td>2760 E FLORENCE AVE</td>
      <td>NaN</td>
      <td>HUNTINGTON PARK</td>
      <td>CA</td>
      <td>33.973776</td>
      <td>-118.220823</td>
      <td>78.2ccc</td>
      <td>5331.07</td>
      <td>13</td>
    </tr>
    <tr>
      <th>93301</th>
      <td>-119.009485</td>
      <td>35.396189</td>
      <td>1588798870</td>
      <td>1588798870</td>
      <td>1</td>
      <td>1</td>
      <td>34TH STREET COMMUNITY HEALTH</td>
      <td>1997-02-05T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>2000 PHYSICIANS BLVD</td>
      <td>NaN</td>
      <td>BAKERSFIELD</td>
      <td>CA</td>
      <td>35.396189</td>
      <td>-119.009485</td>
      <td>66a</td>
      <td>6.00</td>
      <td>14</td>
    </tr>
    <tr>
      <th>90057</th>
      <td>-118.275105</td>
      <td>34.055679</td>
      <td>1689978850</td>
      <td>1689978850</td>
      <td>1</td>
      <td>1</td>
      <td>7TH ST MEDICAL GROUP</td>
      <td>2011-03-22T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>GROUP INC</td>
      <td>1919 W 7TH ST</td>
      <td>STE 2A</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.055679</td>
      <td>-118.275105</td>
      <td>78.2b</td>
      <td>2094.02</td>
      <td>15</td>
    </tr>
    <tr>
      <th>92103</th>
      <td>-117.161281</td>
      <td>32.740195</td>
      <td>1568800100</td>
      <td>1568800100</td>
      <td>1</td>
      <td>1</td>
      <td>BEST START MIDWIFE SERVICES</td>
      <td>2015-02-02T08:00:00.000Z</td>
      <td>5</td>
      <td>CERTIFIED NURSE MIDWIFE</td>
      <td>...</td>
      <td>NaN</td>
      <td>3343 4TH AVE</td>
      <td>NaN</td>
      <td>SAN DIEGO</td>
      <td>CA</td>
      <td>32.740195</td>
      <td>-117.161281</td>
      <td>161e</td>
      <td>60.00</td>
      <td>16</td>
    </tr>
    <tr>
      <th>90640</th>
      <td>-118.100423</td>
      <td>34.016047</td>
      <td>1184628919</td>
      <td>1184628919</td>
      <td>1</td>
      <td>1</td>
      <td>BEVERLY HOSPITAL</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>15</td>
      <td>COMMUNITY OUTPATIENT HOSPITAL</td>
      <td>...</td>
      <td>NaN</td>
      <td>309 W BEVERLY BLVD</td>
      <td>NaN</td>
      <td>MONTEBELLO</td>
      <td>CA</td>
      <td>34.016047</td>
      <td>-118.100423</td>
      <td>78.2nn</td>
      <td>5300.04</td>
      <td>17</td>
    </tr>
    <tr>
      <th>91605</th>
      <td>-118.387784</td>
      <td>34.205963</td>
      <td>1396067500</td>
      <td>1396067500</td>
      <td>1</td>
      <td>1</td>
      <td>AAA COMPREHENSIVE HEALTHCARE</td>
      <td>2010-04-30T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>7451 N LANKERSHIM BLVD</td>
      <td>NaN</td>
      <td>NORTH HOLLYWOOD</td>
      <td>CA</td>
      <td>34.205963</td>
      <td>-118.387784</td>
      <td>78.2bb</td>
      <td>1224.10</td>
      <td>18</td>
    </tr>
    <tr>
      <th>90260</th>
      <td>-118.352348</td>
      <td>33.878380</td>
      <td>1629192133</td>
      <td>1629192133</td>
      <td>1</td>
      <td>1</td>
      <td>BEVERLY, SHEREEN L MD</td>
      <td>1990-02-28T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>INC</td>
      <td>16812 HAWTHORNE BLVD</td>
      <td>NaN</td>
      <td>LAWNDALE</td>
      <td>CA</td>
      <td>33.878380</td>
      <td>-118.352348</td>
      <td>78.2iiii</td>
      <td>6041.00</td>
      <td>19</td>
    </tr>
    <tr>
      <th>90001</th>
      <td>-118.256403</td>
      <td>33.961796</td>
      <td>1316061674</td>
      <td>1316061674</td>
      <td>1</td>
      <td>1</td>
      <td>ABAIAN, ALI MD</td>
      <td>2001-04-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>8460 S CENTRAL AVENUE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>33.961796</td>
      <td>-118.256403</td>
      <td>78.2fff</td>
      <td>2398.02</td>
      <td>20</td>
    </tr>
    <tr>
      <th>92701</th>
      <td>-117.854493</td>
      <td>33.759883</td>
      <td>1861680712</td>
      <td>1861680712</td>
      <td>1</td>
      <td>1</td>
      <td>BIENESTAR MEDICAL CENTER</td>
      <td>2006-11-02T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>INC</td>
      <td>1125 E 17TH STREET</td>
      <td>SUITE N 152</td>
      <td>SANTA ANA</td>
      <td>CA</td>
      <td>33.759883</td>
      <td>-117.854493</td>
      <td>116h</td>
      <td>754.03</td>
      <td>21</td>
    </tr>
    <tr>
      <th>92201</th>
      <td>-116.239207</td>
      <td>33.707410</td>
      <td>1043281108</td>
      <td>1043281108</td>
      <td>1</td>
      <td>1</td>
      <td>ABHYANKAR, S.R. MD PC</td>
      <td>2006-04-11T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>81-709 DR CARREON BLVD</td>
      <td>STE C1</td>
      <td>INDIO</td>
      <td>CA</td>
      <td>33.707410</td>
      <td>-116.239207</td>
      <td>128</td>
      <td>452.07</td>
      <td>22</td>
    </tr>
    <tr>
      <th>90022</th>
      <td>-118.155282</td>
      <td>34.026948</td>
      <td>1497001226</td>
      <td>1497001226</td>
      <td>1</td>
      <td>1</td>
      <td>BIENVENIDOS COMMUNITY HEALTH</td>
      <td>2013-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>INC</td>
      <td>507 S. ATLANTIC BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.026948</td>
      <td>-118.155282</td>
      <td>78.2d</td>
      <td>5303.01</td>
      <td>23</td>
    </tr>
    <tr>
      <th>92315</th>
      <td>-116.888382</td>
      <td>34.244060</td>
      <td>1578535845</td>
      <td>1578535845</td>
      <td>1</td>
      <td>5</td>
      <td>BIG BEAR PUBLIC HEALTH CLINI</td>
      <td>1977-12-01T08:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>NaN</td>
      <td>477 SUMMIT BLVD</td>
      <td>NaN</td>
      <td>BIG BEAR LAKE</td>
      <td>CA</td>
      <td>34.244060</td>
      <td>-116.888382</td>
      <td>146</td>
      <td>112.03</td>
      <td>24</td>
    </tr>
    <tr>
      <th>95203</th>
      <td>-121.299230</td>
      <td>37.961437</td>
      <td>1073619060</td>
      <td>1073619060</td>
      <td>1</td>
      <td>1</td>
      <td>BIG VALLEY OB-GYN MEDICAL</td>
      <td>1988-01-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>CENTER INC</td>
      <td>420 W ACACIA ST</td>
      <td>STE 11</td>
      <td>STOCKTON</td>
      <td>CA</td>
      <td>37.961437</td>
      <td>-121.299230</td>
      <td>169b</td>
      <td>4.01</td>
      <td>25</td>
    </tr>
    <tr>
      <th>95948</th>
      <td>-121.690577</td>
      <td>39.366966</td>
      <td>1578708285</td>
      <td>1578708285</td>
      <td>1</td>
      <td>1</td>
      <td>BIGGS GRIDLEY HOSP</td>
      <td>1998-10-13T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>FAMILY CARE CTR</td>
      <td>240 SPRUCE ST</td>
      <td>NaN</td>
      <td>GRIDLEY</td>
      <td>CA</td>
      <td>39.366966</td>
      <td>-121.690577</td>
      <td>9</td>
      <td>35.02</td>
      <td>26</td>
    </tr>
    <tr>
      <th>92376</th>
      <td>-117.370486</td>
      <td>34.103910</td>
      <td>1275656761</td>
      <td>1275656761</td>
      <td>1</td>
      <td>1</td>
      <td>BIR, RAGHBIR S MD</td>
      <td>1998-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>280 N RIVERSIDE AVE</td>
      <td>NaN</td>
      <td>RIALTO</td>
      <td>CA</td>
      <td>34.103910</td>
      <td>-117.370486</td>
      <td>151h</td>
      <td>37.00</td>
      <td>27</td>
    </tr>
    <tr>
      <th>92335</th>
      <td>-117.435763</td>
      <td>34.075913</td>
      <td>1568585024</td>
      <td>1568585024</td>
      <td>1</td>
      <td>1</td>
      <td>BIR, RAGHBIR S MD</td>
      <td>2001-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>9792 SIERRA AVE</td>
      <td>NaN</td>
      <td>FONTANA</td>
      <td>CA</td>
      <td>34.075913</td>
      <td>-117.435763</td>
      <td>151f</td>
      <td>33.01</td>
      <td>28</td>
    </tr>
    <tr>
      <th>93514</th>
      <td>-118.418372</td>
      <td>37.362022</td>
      <td>1659433191</td>
      <td>1659433191</td>
      <td>1</td>
      <td>3</td>
      <td>BISHOP CLINIC</td>
      <td>1991-11-01T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>BISHOP CLINIC</td>
      <td>52 TU SU LANE</td>
      <td>NaN</td>
      <td>BISHOP</td>
      <td>CA</td>
      <td>37.362022</td>
      <td>-118.418372</td>
      <td>53</td>
      <td>4.00</td>
      <td>29</td>
    </tr>
    <tr>
      <th>92627</th>
      <td>-117.919049</td>
      <td>33.649959</td>
      <td>1841419793</td>
      <td>1841419793</td>
      <td>1</td>
      <td>1</td>
      <td>BLACK, ROBIN</td>
      <td>2007-02-07T08:00:00.000Z</td>
      <td>7</td>
      <td>CERTIFIED NURSE PRACTIONER</td>
      <td>...</td>
      <td>NaN</td>
      <td>2077 HARBOR BLVD</td>
      <td>STE C</td>
      <td>COSTA MESA</td>
      <td>CA</td>
      <td>33.649959</td>
      <td>-117.919049</td>
      <td>116p</td>
      <td>637.02</td>
      <td>30</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>94607</th>
      <td>-122.271239</td>
      <td>37.799511</td>
      <td>1225179641</td>
      <td>1225179641</td>
      <td>1</td>
      <td>1</td>
      <td>ROLLAND AND KATHRYN LOWE MED</td>
      <td>1996-10-23T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>835 WEBSTER ST</td>
      <td>NaN</td>
      <td>OAKLAND</td>
      <td>CA</td>
      <td>37.799511</td>
      <td>-122.271239</td>
      <td>2c</td>
      <td>4030.00</td>
      <td>1801</td>
    </tr>
    <tr>
      <th>90255</th>
      <td>-118.212379</td>
      <td>33.972891</td>
      <td>1114032208</td>
      <td>1114032208</td>
      <td>1</td>
      <td>1</td>
      <td>ROMERO, JESUSA N MD APC</td>
      <td>1988-12-31T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>3100 E FLORENCE AVE</td>
      <td>STE 5</td>
      <td>HUNTINGTON PARK</td>
      <td>CA</td>
      <td>33.972891</td>
      <td>-118.212379</td>
      <td>78.2ccc</td>
      <td>5332.03</td>
      <td>1802</td>
    </tr>
    <tr>
      <th>90201</th>
      <td>-118.176068</td>
      <td>33.969061</td>
      <td>1861576480</td>
      <td>1861576480</td>
      <td>1</td>
      <td>1</td>
      <td>ROMO, MARY S MD INC</td>
      <td>1991-12-31T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>5101 FLORENCE AVE</td>
      <td>STE 5</td>
      <td>BELL</td>
      <td>CA</td>
      <td>33.969061</td>
      <td>-118.176068</td>
      <td>78.2ddd</td>
      <td>5338.05</td>
      <td>1803</td>
    </tr>
    <tr>
      <th>90095</th>
      <td>-118.445025</td>
      <td>34.068908</td>
      <td>1902803315</td>
      <td>1902803315</td>
      <td>1</td>
      <td>1</td>
      <td>RONALD REAGAN UCLA MED</td>
      <td>2005-07-01T07:00:00.000Z</td>
      <td>15</td>
      <td>COMMUNITY OUTPATIENT HOSPITAL</td>
      <td>...</td>
      <td>CALIFORNIA</td>
      <td>757 WESTWOOD PLAZA</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.068908</td>
      <td>-118.445025</td>
      <td>78.2w</td>
      <td>2653.01</td>
      <td>1804</td>
    </tr>
    <tr>
      <th>94606</th>
      <td>-122.237990</td>
      <td>37.789727</td>
      <td>1851522015</td>
      <td>1851522015</td>
      <td>1</td>
      <td>1</td>
      <td>ROOSEVELT HEALTH CENTER</td>
      <td>2009-11-12T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>1926 19TH AVE</td>
      <td>NaN</td>
      <td>OAKLAND</td>
      <td>CA</td>
      <td>37.789727</td>
      <td>-122.237990</td>
      <td>2c</td>
      <td>4059.02</td>
      <td>1805</td>
    </tr>
    <tr>
      <th>95407</th>
      <td>-122.741560</td>
      <td>38.429307</td>
      <td>1558512624</td>
      <td>1558512624</td>
      <td>1</td>
      <td>1</td>
      <td>ROSELAND PEDIATRICS</td>
      <td>2008-09-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>711 STONY POINT ROAD</td>
      <td>SUITE 17</td>
      <td>SANTA ROSA</td>
      <td>CA</td>
      <td>38.429307</td>
      <td>-122.741560</td>
      <td>210.1</td>
      <td>1531.04</td>
      <td>1806</td>
    </tr>
    <tr>
      <th>91605</th>
      <td>-118.396526</td>
      <td>34.215715</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>5</td>
      <td>ROY MEDICAL GROUP INC</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>8001 LAUREL CANYON BLVD</td>
      <td>STE 109</td>
      <td>NORTH HOLLYWOOD</td>
      <td>CA</td>
      <td>34.215715</td>
      <td>-118.396526</td>
      <td>78.2ppp</td>
      <td>1210.20</td>
      <td>1807</td>
    </tr>
    <tr>
      <th>91303</th>
      <td>-118.590600</td>
      <td>34.201103</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>1</td>
      <td>ROY, ROSALINDA A MD</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>21001 SHERMAN WAY</td>
      <td>STE 15</td>
      <td>CANOGA PARK</td>
      <td>CA</td>
      <td>34.201103</td>
      <td>-118.590600</td>
      <td>78.2hhhh</td>
      <td>1340.01</td>
      <td>1808</td>
    </tr>
    <tr>
      <th>91406</th>
      <td>-118.482831</td>
      <td>34.193904</td>
      <td>1801921952</td>
      <td>1801921952</td>
      <td>1</td>
      <td>2</td>
      <td>ROY, ROSALINDA A MD</td>
      <td>1996-01-01T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>16063 VANOWEN ST</td>
      <td>NaN</td>
      <td>VAN NUYS</td>
      <td>CA</td>
      <td>34.193904</td>
      <td>-118.482831</td>
      <td>78.2cc</td>
      <td>1276.05</td>
      <td>1809</td>
    </tr>
    <tr>
      <th>91764</th>
      <td>-117.642495</td>
      <td>34.068248</td>
      <td>1619144227</td>
      <td>1619144227</td>
      <td>1</td>
      <td>1</td>
      <td>ROYAL CARE MEDICAL CENTER</td>
      <td>2011-01-11T08:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>CENTER INC</td>
      <td>653 E E ST</td>
      <td>STE 109</td>
      <td>ONTARIO</td>
      <td>CA</td>
      <td>34.068248</td>
      <td>-117.642495</td>
      <td>151c</td>
      <td>15.01</td>
      <td>1810</td>
    </tr>
    <tr>
      <th>90022</th>
      <td>-118.160915</td>
      <td>34.034141</td>
      <td>1083627749</td>
      <td>1083627749</td>
      <td>1</td>
      <td>1</td>
      <td>ROYBAL COMPREHENSIVE HLT</td>
      <td>1997-04-10T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>ROYBAL COMPREHENSIVE HLT</td>
      <td>245 S FETTERLY AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.034141</td>
      <td>-118.160915</td>
      <td>78.2d</td>
      <td>5304.00</td>
      <td>1811</td>
    </tr>
    <tr>
      <th>91710</th>
      <td>-117.689596</td>
      <td>34.040964</td>
      <td>1740303247</td>
      <td>1740303247</td>
      <td>1</td>
      <td>1</td>
      <td>RS BIR MD INC CLINICA MEDIC</td>
      <td>1998-07-01T07:00:00.000Z</td>
      <td>22</td>
      <td>PHYSICIANS GROUP</td>
      <td>...</td>
      <td>NaN</td>
      <td>11692 CENTRAL AVE</td>
      <td>NaN</td>
      <td>CHINO</td>
      <td>CA</td>
      <td>34.040964</td>
      <td>-117.689596</td>
      <td>151l</td>
      <td>4.04</td>
      <td>1812</td>
    </tr>
    <tr>
      <th>92382</th>
      <td>-117.152437</td>
      <td>34.206947</td>
      <td>1881703957</td>
      <td>1881703957</td>
      <td>1</td>
      <td>1</td>
      <td>RURAL HEALTH CLINIC</td>
      <td>2008-01-09T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>COMMUNITAL HOSPITAL DIST</td>
      <td>31900 HILLTOP BLVD</td>
      <td>NaN</td>
      <td>RUNNING SPRINGS</td>
      <td>CA</td>
      <td>34.206947</td>
      <td>-117.152437</td>
      <td>146</td>
      <td>111.01</td>
      <td>1813</td>
    </tr>
    <tr>
      <th>90011</th>
      <td>-118.256479</td>
      <td>34.003304</td>
      <td>1396891909</td>
      <td>1396891909</td>
      <td>1</td>
      <td>1</td>
      <td>S CENTRAL FAMILY HLTH CT</td>
      <td>1994-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HEALTH CTR</td>
      <td>4425 S CENTRAL AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.003304</td>
      <td>-118.256479</td>
      <td>78.2ggg</td>
      <td>2286.00</td>
      <td>1814</td>
    </tr>
    <tr>
      <th>90037</th>
      <td>-118.274009</td>
      <td>34.010416</td>
      <td>1487923306</td>
      <td>1487923306</td>
      <td>1</td>
      <td>1</td>
      <td>S MARK TAPER FNDN HEALTH</td>
      <td>2012-03-09T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>4000 S MAIN STREET</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.010416</td>
      <td>-118.274009</td>
      <td>78.2l</td>
      <td>2318.00</td>
      <td>1815</td>
    </tr>
    <tr>
      <th>93460</th>
      <td>-120.093733</td>
      <td>34.606060</td>
      <td>1992779417</td>
      <td>1992779417</td>
      <td>1</td>
      <td>1</td>
      <td>S Y BAND OF MISSION IND</td>
      <td>1991-09-27T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>CLINIC</td>
      <td>90 VIA JUANA RD</td>
      <td>NaN</td>
      <td>SANTA YNEZ</td>
      <td>CA</td>
      <td>34.606060</td>
      <td>-120.093733</td>
      <td>178.1</td>
      <td>19.06</td>
      <td>1816</td>
    </tr>
    <tr>
      <th>90029</th>
      <td>-118.291710</td>
      <td>34.087012</td>
      <td>1891806329</td>
      <td>1891806329</td>
      <td>1</td>
      <td>2</td>
      <td>SABABA, LILIAN E MD</td>
      <td>1991-02-28T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>866 N VERMONT AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.087012</td>
      <td>-118.291710</td>
      <td>78.2g</td>
      <td>1914.10</td>
      <td>1817</td>
    </tr>
    <tr>
      <th>90028</th>
      <td>-118.321100</td>
      <td>34.101663</td>
      <td>1235271065</td>
      <td>1235271065</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN COMMUNITY CLINIC</td>
      <td>1997-06-24T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HOLLYWOOD HEALTH CENTER</td>
      <td>6043 HOLLYWOOD BLVD</td>
      <td>NaN</td>
      <td>HOLLYWOOD</td>
      <td>CA</td>
      <td>34.101663</td>
      <td>-118.321100</td>
      <td>78.2a</td>
      <td>1910.00</td>
      <td>1818</td>
    </tr>
    <tr>
      <th>90038</th>
      <td>-118.313671</td>
      <td>34.083520</td>
      <td>1336281179</td>
      <td>1336281179</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN COMMUNITY CLINIC</td>
      <td>2002-04-17T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>HOLLYWOOD WILSHIRE HLTH</td>
      <td>5205 MELROSE AVE</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.083520</td>
      <td>-118.313671</td>
      <td>78.2g</td>
      <td>1917.10</td>
      <td>1819</td>
    </tr>
    <tr>
      <th>90048</th>
      <td>-118.373295</td>
      <td>34.076063</td>
      <td>1194893248</td>
      <td>1194893248</td>
      <td>1</td>
      <td>1</td>
      <td>SABAN FREE CLINIC BEVERLY</td>
      <td>1994-07-01T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>8405 BEVERLY BLVD</td>
      <td>NaN</td>
      <td>LOS ANGELES</td>
      <td>CA</td>
      <td>34.076063</td>
      <td>-118.373295</td>
      <td>78.2f</td>
      <td>1945.00</td>
      <td>1820</td>
    </tr>
    <tr>
      <th>93622</th>
      <td>-120.458268</td>
      <td>36.860624</td>
      <td>1558638601</td>
      <td>1558638601</td>
      <td>1</td>
      <td>1</td>
      <td>SABLAN HEALTH CENTER</td>
      <td>2012-03-12T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>927 O STREET</td>
      <td>NaN</td>
      <td>FIREBAUGH</td>
      <td>CA</td>
      <td>36.860624</td>
      <td>-120.458268</td>
      <td>25</td>
      <td>84.01</td>
      <td>1821</td>
    </tr>
    <tr>
      <th>92410</th>
      <td>-117.298641</td>
      <td>34.097379</td>
      <td>1801270137</td>
      <td>1801270137</td>
      <td>1</td>
      <td>1</td>
      <td>SAC SAN BERNARDINO CAMPUS</td>
      <td>2016-07-15T07:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>NaN</td>
      <td>250 SOUTH G STREET</td>
      <td>NaN</td>
      <td>SAN BERNARDINO</td>
      <td>CA</td>
      <td>34.097379</td>
      <td>-117.298641</td>
      <td>151g</td>
      <td>57.01</td>
      <td>1822</td>
    </tr>
    <tr>
      <th>95815</th>
      <td>-121.450815</td>
      <td>38.610077</td>
      <td>1538180245</td>
      <td>1538180245</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMM CLINIC</td>
      <td>2006-11-22T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>ORGANIZATION INC</td>
      <td>2200 DEL PASO BLVD</td>
      <td>NaN</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.610077</td>
      <td>-121.450815</td>
      <td>139j</td>
      <td>69.00</td>
      <td>1823</td>
    </tr>
    <tr>
      <th>95823</th>
      <td>-121.437707</td>
      <td>38.493421</td>
      <td>1740336734</td>
      <td>1740336734</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMM CLINIC</td>
      <td>2006-11-21T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>ORGANIZATION INC</td>
      <td>7275 E SOUTHGATE DR</td>
      <td>STE 204-206</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.493421</td>
      <td>-121.437707</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1824</td>
    </tr>
    <tr>
      <th>95823</th>
      <td>-121.440792</td>
      <td>38.493662</td>
      <td>1295044832</td>
      <td>1295044832</td>
      <td>1</td>
      <td>1</td>
      <td>SACRAMENTO COMMUNITY CLINIC</td>
      <td>2012-02-22T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>INC</td>
      <td>5524 ASSEMBLY COURT</td>
      <td>SUITE 200</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.493662</td>
      <td>-121.440792</td>
      <td>139k</td>
      <td>50.02</td>
      <td>1825</td>
    </tr>
    <tr>
      <th>95811</th>
      <td>-121.479589</td>
      <td>38.576631</td>
      <td>1588756530</td>
      <td>1588756530</td>
      <td>1</td>
      <td>3</td>
      <td>SACRAMENTO NATIVE AMER</td>
      <td>2006-12-20T08:00:00.000Z</td>
      <td>58</td>
      <td>HEALTH ACCESS PROGRAM</td>
      <td>...</td>
      <td>AMERICAN HEALTH CTR, INC</td>
      <td>2020 J ST</td>
      <td>NaN</td>
      <td>SACRAMENTO</td>
      <td>CA</td>
      <td>38.576631</td>
      <td>-121.479589</td>
      <td>139j</td>
      <td>11.01</td>
      <td>1826</td>
    </tr>
    <tr>
      <th>92692</th>
      <td>-117.667255</td>
      <td>33.557040</td>
      <td>1376905026</td>
      <td>1376905026</td>
      <td>1</td>
      <td>1</td>
      <td>SADDLEBACK COLLEGE</td>
      <td>2016-05-18T07:00:00.000Z</td>
      <td>45</td>
      <td>CLINIC EXEMP FROM LICENSURE</td>
      <td>...</td>
      <td>COMMUNITY COLLEGE DISTRI</td>
      <td>28000 MARGUERITE PARKWAY</td>
      <td>NaN</td>
      <td>MISSION VIEJO</td>
      <td>CA</td>
      <td>33.557040</td>
      <td>-117.667255</td>
      <td>115.2a</td>
      <td>320.22</td>
      <td>1827</td>
    </tr>
    <tr>
      <th>92801</th>
      <td>-117.941811</td>
      <td>33.850820</td>
      <td>1124296496</td>
      <td>1124296496</td>
      <td>1</td>
      <td>1</td>
      <td>SAENZ, LUCY M MD</td>
      <td>2002-12-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>1203 N EUCLID ST</td>
      <td>NaN</td>
      <td>ANAHEIM</td>
      <td>CA</td>
      <td>33.850820</td>
      <td>-117.941811</td>
      <td>116l</td>
      <td>867.01</td>
      <td>1828</td>
    </tr>
    <tr>
      <th>92701</th>
      <td>-117.853557</td>
      <td>33.759898</td>
      <td>1548367436</td>
      <td>1548367436</td>
      <td>1</td>
      <td>1</td>
      <td>SAENZ, LUCY M MD INC</td>
      <td>1998-05-01T07:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>NaN</td>
      <td>1215 E 17TH ST</td>
      <td>NaN</td>
      <td>SANTA ANA</td>
      <td>CA</td>
      <td>33.759898</td>
      <td>-117.853557</td>
      <td>116h</td>
      <td>754.03</td>
      <td>1829</td>
    </tr>
    <tr>
      <th>90232</th>
      <td>-118.400917</td>
      <td>34.020459</td>
      <td>1306945241</td>
      <td>1306945241</td>
      <td>1</td>
      <td>1</td>
      <td>SAINT ANA WOMEN MED CLNC</td>
      <td>1999-02-01T08:00:00.000Z</td>
      <td>26</td>
      <td>PHYSICIANS</td>
      <td>...</td>
      <td>SAINT ANA WOMEN MED CLNC</td>
      <td>3865 JASMINE AVE</td>
      <td>NaN</td>
      <td>CULVER CITY</td>
      <td>CA</td>
      <td>34.020459</td>
      <td>-118.400917</td>
      <td>78.2y</td>
      <td>2699.05</td>
      <td>1830</td>
    </tr>
  </tbody>
</table>
<p>1830 rows × 27 columns</p>
</div>




```python
### Make a numpy series for the zipcode column data
zipcode_arr = df['Provider_Address_Zip'].values
```


```python
### Confirm array type
type(zipcode_arr)
```




    numpy.ndarray




```python
### Use pyplot to display the zipcode array
plt.plot(zipcode_arr)
```




    [<matplotlib.lines.Line2D at 0x2bedad020f0>]




![png](output_19_1.png)



```python
### plot a histogram using the zipcode array series with 58 bins (the number of counties in CA)
plt.hist((zipcode_arr), bins=58)
```




    (array([228.,  17., 112.,   4.,   6.,  13.,  52.,  34.,   0.,   3.,   6.,
             11.,  59.,  36.,   5.,   8., 104.,  11.,  17.,  78.,  21.,  47.,
             48.,  33.,  30.,  52.,  36.,  10.,  21.,   7.,  80.,  20.,  30.,
             23.,  77.,  13.,  14.,  10.,  36.,   0.,   4.,   3.,  39.,  37.,
              5.,   6.,  11.,  23.,  36.,  12.,  59.,  40.,  17.,  17.,  31.,
             21.,  38.,  19.]),
     array([90001.        , 90107.20689655, 90213.4137931 , 90319.62068966,
            90425.82758621, 90532.03448276, 90638.24137931, 90744.44827586,
            90850.65517241, 90956.86206897, 91063.06896552, 91169.27586207,
            91275.48275862, 91381.68965517, 91487.89655172, 91594.10344828,
            91700.31034483, 91806.51724138, 91912.72413793, 92018.93103448,
            92125.13793103, 92231.34482759, 92337.55172414, 92443.75862069,
            92549.96551724, 92656.17241379, 92762.37931034, 92868.5862069 ,
            92974.79310345, 93081.        , 93187.20689655, 93293.4137931 ,
            93399.62068966, 93505.82758621, 93612.03448276, 93718.24137931,
            93824.44827586, 93930.65517241, 94036.86206897, 94143.06896552,
            94249.27586207, 94355.48275862, 94461.68965517, 94567.89655172,
            94674.10344828, 94780.31034483, 94886.51724138, 94992.72413793,
            95098.93103448, 95205.13793103, 95311.34482759, 95417.55172414,
            95523.75862069, 95629.96551724, 95736.17241379, 95842.37931034,
            95948.5862069 , 96054.79310345, 96161.        ]),
     <a list of 58 Patch objects>)




![png](output_20_1.png)



```python
###  Trying another way
zipcode_series = df['Provider_Address_Zip']
```


```python
type(zipcode_series)
```




    pandas.core.series.Series




```python
plt.plot(zipcode_series)
```




    [<matplotlib.lines.Line2D at 0x2bedf2cdf60>]




![png](output_23_1.png)



```python
df.plot()
plt.yscale('log')
```


![png](output_24_0.png)



```python
### Plot all columns as subplots
df.plot(subplots=True)
plt.show()
```


![png](output_25_0.png)



```python
### Plot only the Provider_Type_Code and City data
z_list =['Provider_Type_Code','Provider_Address_City']
df[z_list].plot()
plt.show()
```


![png](output_26_0.png)



```python
### Run a Cumulative distribution on the Provider_Type_Code as a histogram
df.plot(y='Provider_Type_code', kind='box', bins=60, range=(0,60), cumulative=True, normed=True)
plt.xlabel('Provider_Type_Code_Desc')
plt.show()
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       3062             try:
    -> 3063                 return self._engine.get_loc(key)
       3064             except KeyError:
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'Provider_Type_code'

    
    During handling of the above exception, another exception occurred:
    

    KeyError                                  Traceback (most recent call last)

    <ipython-input-83-43a400692d1c> in <module>()
          1 ### Run a Cumulative distribution on the Provider_Type_Code as a histogram
    ----> 2 df.plot(y='Provider_Type_code', kind='box', bins=60, range=(0,60), cumulative=True, normed=True)
          3 plt.xlabel('Provider_Type_Code_Desc')
          4 plt.show()
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\plotting\_core.py in __call__(self, x, y, kind, ax, subplots, sharex, sharey, layout, figsize, use_index, title, grid, legend, style, logx, logy, loglog, xticks, yticks, xlim, ylim, rot, fontsize, colormap, table, yerr, xerr, secondary_y, sort_columns, **kwds)
       2939                           fontsize=fontsize, colormap=colormap, table=table,
       2940                           yerr=yerr, xerr=xerr, secondary_y=secondary_y,
    -> 2941                           sort_columns=sort_columns, **kwds)
       2942     __call__.__doc__ = plot_frame.__doc__
       2943 
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\plotting\_core.py in plot_frame(data, x, y, kind, ax, subplots, sharex, sharey, layout, figsize, use_index, title, grid, legend, style, logx, logy, loglog, xticks, yticks, xlim, ylim, rot, fontsize, colormap, table, yerr, xerr, secondary_y, sort_columns, **kwds)
       1975                  yerr=yerr, xerr=xerr,
       1976                  secondary_y=secondary_y, sort_columns=sort_columns,
    -> 1977                  **kwds)
       1978 
       1979 
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\plotting\_core.py in _plot(data, x, y, subplots, ax, kind, **kwds)
       1786 
       1787                 # don't overwrite
    -> 1788                 data = data[y].copy()
       1789 
       1790                 if isinstance(data, ABCSeries):
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\core\frame.py in __getitem__(self, key)
       2683             return self._getitem_multilevel(key)
       2684         else:
    -> 2685             return self._getitem_column(key)
       2686 
       2687     def _getitem_column(self, key):
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\core\frame.py in _getitem_column(self, key)
       2690         # get column
       2691         if self.columns.is_unique:
    -> 2692             return self._get_item_cache(key)
       2693 
       2694         # duplicate columns & possible reduce dimensionality
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\core\generic.py in _get_item_cache(self, item)
       2484         res = cache.get(item)
       2485         if res is None:
    -> 2486             values = self._data.get(item)
       2487             res = self._box_item_values(item, values)
       2488             cache[item] = res
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\core\internals.py in get(self, item, fastpath)
       4113 
       4114             if not isna(item):
    -> 4115                 loc = self.items.get_loc(item)
       4116             else:
       4117                 indexer = np.arange(len(self.items))[isna(self.items)]
    

    C:\Users\Public\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       3063                 return self._engine.get_loc(key)
       3064             except KeyError:
    -> 3065                 return self._engine.get_loc(self._maybe_cast_indexer(key))
       3066 
       3067         indexer = self.get_indexer([key], method=method, tolerance=tolerance)
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'Provider_Type_code'



```python
### Return the number of entries of zipcodes in the series (column)
df['Provider_Address_Zip'].describe()
```




    count     1830.000000
    mean     92610.478142
    std       1878.618118
    min      90001.000000
    25%      90813.000000
    50%      92411.000000
    75%      93960.000000
    max      96161.000000
    Name: Provider_Address_Zip, dtype: float64




```python
###  Finally find all of the unique zipcodes from the DataFrame; assign to zc_array
zc_array = df['Provider_Address_Zip'].unique()
```


```python
zc_array.shape
```




    (704,)




```python
import seaborn as sns
```


```python
sns.__version__
```




    '0.8.1'




```python
# making a line graph with Seaborn
sns.lineplot(x='Provider_Address_Zip', y='Provider_Address_city', hue='country',data=df)
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-57-4c74ffa69305> in <module>()
          1 # making a line graph with Seaborn
    ----> 2 sns.lineplot(x='Provider_Address_Zip', y='Provider_Address_city', hue='country',data=df)
    

    AttributeError: module 'seaborn' has no attribute 'lineplot'



```python
###  Use seaborn to better visualize the data
plt.style.use('seaborn-dark')
zipcode_arr.hist(bins=20)
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-56-1a703e93aa2a> in <module>()
          1 ###  Use seaborn to better visualize the data
          2 plt.style.use('seaborn-dark')
    ----> 3 zipcode_arr.hist(bins=20)
    

    AttributeError: 'numpy.ndarray' object has no attribute 'hist'



```python
# solution
plt.figure(figsize=(5,5)) # note: figure size argument must come before the figure is generated
df['gdp per cap'].hist(bins=50)
plt.title('what a gorgeous plot title!')
plt.savefig('my_hist.pdf')
```
